package com.vacc.web.mapper;

import com.vacc.web.pojo.InspectType;
import com.vacc.web.pojo.InspectTypeExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface InspectTypeMapper {
    int countByExample(InspectTypeExample example);

    int deleteByExample(InspectTypeExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(InspectType record);

    int insertSelective(InspectType record);

    List<InspectType> selectByExample(InspectTypeExample example);

    InspectType selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") InspectType record, @Param("example") InspectTypeExample example);

    int updateByExample(@Param("record") InspectType record, @Param("example") InspectTypeExample example);

    int updateByPrimaryKeySelective(InspectType record);

    int updateByPrimaryKey(InspectType record);
}
package com.vacc.web.mapper;

import com.vacc.web.pojo.GeneralSampling;
import com.vacc.web.pojo.GeneralSamplingExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface GeneralSamplingMapper {
    int countByExample(GeneralSamplingExample example);

    int deleteByExample(GeneralSamplingExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(GeneralSampling record);

    int insertSelective(GeneralSampling record);

    List<GeneralSampling> selectByExample(GeneralSamplingExample example);

    GeneralSampling selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") GeneralSampling record, @Param("example") GeneralSamplingExample example);

    int updateByExample(@Param("record") GeneralSampling record, @Param("example") GeneralSamplingExample example);

    int updateByPrimaryKeySelective(GeneralSampling record);

    int updateByPrimaryKey(GeneralSampling record);
}
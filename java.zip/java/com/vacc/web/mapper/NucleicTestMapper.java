package com.vacc.web.mapper;

import com.vacc.web.pojo.NucleicTest;
import com.vacc.web.pojo.NucleicTestExample;

import java.util.Date;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface NucleicTestMapper {
    int countByExample(NucleicTestExample example);

    int deleteByExample(NucleicTestExample example);

    int deleteByPrimaryKey(Long id);

    int insert(NucleicTest record);

    int insertSelective(NucleicTest record);

    List<NucleicTest> selectByExample(NucleicTestExample example);

    NucleicTest selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") NucleicTest record, @Param("example") NucleicTestExample example);

    int updateByExample(@Param("record") NucleicTest record, @Param("example") NucleicTestExample example);

    int updateByPrimaryKeySelective(NucleicTest record);

    int updateByPrimaryKey(NucleicTest record);

    List<NucleicTest> selectNucleicTestResult(@Param("name")String name, @Param("time") Date time, @Param("result") Integer result, @Param("detectionid") Integer detectionid);
}
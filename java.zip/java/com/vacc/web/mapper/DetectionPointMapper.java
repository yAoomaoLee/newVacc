package com.vacc.web.mapper;

import com.vacc.web.pojo.DetectionPoint;
import com.vacc.web.pojo.DetectionPointExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface DetectionPointMapper {
    int countByExample(DetectionPointExample example);

    int deleteByExample(DetectionPointExample example);

    int deleteByPrimaryKey(Integer detectionid);

    int insert(DetectionPoint record);

    int insertSelective(DetectionPoint record);

    List<DetectionPoint> selectByExample(DetectionPointExample example);

    DetectionPoint selectByPrimaryKey(Integer detectionid);

    int updateByExampleSelective(@Param("record") DetectionPoint record, @Param("example") DetectionPointExample example);

    int updateByExample(@Param("record") DetectionPoint record, @Param("example") DetectionPointExample example);

    int updateByPrimaryKeySelective(DetectionPoint record);

    int updateByPrimaryKey(DetectionPoint record);
}
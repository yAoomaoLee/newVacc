package com.vacc.web.mapper;

import com.vacc.web.pojo.IVaccines;
import com.vacc.web.pojo.IVaccinesExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface IVaccinesMapper {
    int countByExample(IVaccinesExample example);

    int deleteByExample(IVaccinesExample example);

    int deleteByPrimaryKey(Long id);

    int insert(IVaccines record);

    int insertSelective(IVaccines record);

    List<IVaccines> selectByExample(IVaccinesExample example);

    IVaccines selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") IVaccines record, @Param("example") IVaccinesExample example);

    int updateByExample(@Param("record") IVaccines record, @Param("example") IVaccinesExample example);

    int updateByPrimaryKeySelective(IVaccines record);

    int updateByPrimaryKey(IVaccines record);

    int deleteOne(@Param("id") Long id);

    int addOne(@Param("id")int id);
}
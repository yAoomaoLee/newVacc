package com.vacc.web.mapper;

import com.vacc.web.pojo.LsSampling;
import com.vacc.web.pojo.LsSamplingExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface LsSamplingMapper {
    int countByExample(LsSamplingExample example);

    int deleteByExample(LsSamplingExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(LsSampling record);

    int insertSelective(LsSampling record);

    List<LsSampling> selectByExample(LsSamplingExample example);

    LsSampling selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") LsSampling record, @Param("example") LsSamplingExample example);

    int updateByExample(@Param("record") LsSampling record, @Param("example") LsSamplingExample example);

    int updateByPrimaryKeySelective(LsSampling record);

    int updateByPrimaryKey(LsSampling record);
}
package com.vacc.web.mapper;

import com.vacc.web.pojo.InoculationHistory;
import com.vacc.web.pojo.InoculationHistoryExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface InoculationHistoryMapper {
    int countByExample(InoculationHistoryExample example);

    int deleteByExample(InoculationHistoryExample example);

    int deleteByPrimaryKey(Long historyid);

    int insert(InoculationHistory record);

    int insertSelective(InoculationHistory record);

    List<InoculationHistory> selectByExample(InoculationHistoryExample example);

    InoculationHistory selectByPrimaryKey(Long historyid);

    int updateByExampleSelective(@Param("record") InoculationHistory record, @Param("example") InoculationHistoryExample example);

    int updateByExample(@Param("record") InoculationHistory record, @Param("example") InoculationHistoryExample example);

    int updateByPrimaryKeySelective(InoculationHistory record);

    int updateByPrimaryKey(InoculationHistory record);
}
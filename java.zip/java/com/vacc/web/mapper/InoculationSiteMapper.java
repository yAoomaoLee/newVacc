package com.vacc.web.mapper;

import com.vacc.web.pojo.InoculationSite;
import com.vacc.web.pojo.InoculationSiteExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface InoculationSiteMapper {
    int countByExample(InoculationSiteExample example);

    int deleteByExample(InoculationSiteExample example);

    int deleteByPrimaryKey(Long inoculationid);

    int insert(InoculationSite record);

    int insertSelective(InoculationSite record);

    List<InoculationSite> selectByExample(InoculationSiteExample example);

    InoculationSite selectByPrimaryKey(Long inoculationid);

    int updateByExampleSelective(@Param("record") InoculationSite record, @Param("example") InoculationSiteExample example);

    int updateByExample(@Param("record") InoculationSite record, @Param("example") InoculationSiteExample example);

    int updateByPrimaryKeySelective(InoculationSite record);

    int updateByPrimaryKey(InoculationSite record);
}
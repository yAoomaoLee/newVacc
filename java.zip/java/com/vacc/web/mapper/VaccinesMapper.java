package com.vacc.web.mapper;

import com.vacc.web.pojo.Vaccines;
import com.vacc.web.pojo.VaccinesExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface VaccinesMapper {
    int countByExample(VaccinesExample example);

    int deleteByExample(VaccinesExample example);

    int deleteByPrimaryKey(Long vaccinesid);

    int insert(Vaccines record);

    int insertSelective(Vaccines record);

    List<Vaccines> selectByExample(VaccinesExample example);

    Vaccines selectByPrimaryKey(Long vaccinesid);

    int updateByExampleSelective(@Param("record") Vaccines record, @Param("example") VaccinesExample example);

    int updateByExample(@Param("record") Vaccines record, @Param("example") VaccinesExample example);

    int updateByPrimaryKeySelective(Vaccines record);

    int updateByPrimaryKey(Vaccines record);
}
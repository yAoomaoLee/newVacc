package com.vacc.web.mapper;

import com.vacc.web.pojo.ISiteAndVacc;
import com.vacc.web.pojo.IVaccines;
import com.vacc.web.pojo.IVaccinesExample;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;

public interface ISiteAndVaccMapper {

    //查找所有接种疫苗
    List<ISiteAndVacc> findAllISiteAndVacc(@Param("vaccinesname") String vaccinesname,
                                           @Param("manufactor")String manufactor,
                                           @Param("inoculationname")String inoculationname,
                                           @Param("starttime")Date starttime);

    ISiteAndVacc addiSiteAndVaccById(Long id);
}
package com.vacc.web.mapper;

import com.vacc.web.pojo.CrowdType;
import com.vacc.web.pojo.CrowdTypeExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface CrowdTypeMapper {
    int countByExample(CrowdTypeExample example);

    int deleteByExample(CrowdTypeExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(CrowdType record);

    int insertSelective(CrowdType record);

    List<CrowdType> selectByExample(CrowdTypeExample example);

    CrowdType selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") CrowdType record, @Param("example") CrowdTypeExample example);

    int updateByExample(@Param("record") CrowdType record, @Param("example") CrowdTypeExample example);

    int updateByPrimaryKeySelective(CrowdType record);

    int updateByPrimaryKey(CrowdType record);
}
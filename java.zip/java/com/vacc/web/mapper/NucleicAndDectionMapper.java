package com.vacc.web.mapper;

import com.vacc.web.pojo.NucleicAndDection;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface NucleicAndDectionMapper {

    //查询我的检测历史记录
    public List<NucleicAndDection> selectMyNucleicResult(@Param("userid") Long userid);
    //查询全部检测结果
    List<NucleicAndDection> selectAllNucleicResult();
}
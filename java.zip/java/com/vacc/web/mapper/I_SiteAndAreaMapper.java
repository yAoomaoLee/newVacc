package com.vacc.web.mapper;

import com.vacc.web.pojo.I_SiteAndArea;

import java.util.List;

public interface I_SiteAndAreaMapper {

    //查询所有接种点包括地区
    List<I_SiteAndArea> findAllIsByAreaId();

}
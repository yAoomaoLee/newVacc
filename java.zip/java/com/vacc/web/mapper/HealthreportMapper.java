package com.vacc.web.mapper;

import com.vacc.web.pojo.Healthreport;
import com.vacc.web.pojo.HealthreportExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface HealthreportMapper {
    int countByExample(HealthreportExample example);

    int deleteByExample(HealthreportExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(Healthreport record);

    int insertSelective(Healthreport record);

    List<Healthreport> selectByExample(HealthreportExample example);

    Healthreport selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") Healthreport record, @Param("example") HealthreportExample example);

    int updateByExample(@Param("record") Healthreport record, @Param("example") HealthreportExample example);

    int updateByPrimaryKeySelective(Healthreport record);

    int updateByPrimaryKey(Healthreport record);
}
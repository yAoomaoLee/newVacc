package com.vacc.web.mapper;

import com.vacc.web.pojo.InoculationHistory;
import com.vacc.web.pojo.InoculationHistory2;
import com.vacc.web.pojo.InoculationHistoryExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface InoculationHistoryMapper2 {

    List<InoculationHistory2> findAllInoculationHistory(@Param("userid") long userid);
}
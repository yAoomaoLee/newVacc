package com.vacc.web.utils;

import com.vacc.web.pojo.Area;
import com.vacc.web.pojo.City;
import com.vacc.web.pojo.Province;
import com.vacc.web.service.AreaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

public class AreaUtils {

    @Autowired
    private AreaService areaService;

    public void setAreaToMV(ModelAndView mv){

    }
}

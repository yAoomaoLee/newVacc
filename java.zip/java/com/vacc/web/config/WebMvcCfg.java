package com.vacc.web.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.ClassUtils;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.util.ArrayList;
import java.util.List;

@Configuration
public class WebMvcCfg implements WebMvcConfigurer {
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        String paths= "F:\\Java706-820\\newVacc\\src\\main\\resources\\static\\images\\";
        registry.addResourceHandler("/upload/**").addResourceLocations("file:"+paths);
    }
   /* @Override
    public void addInterceptors(InterceptorRegistry registry) {
        List<String> paths=new ArrayList<>();  //声明放行路径
        paths.add("/login");
        paths.add("/doLogin");
        paths.add("/defaultKaptcha");
        paths.add("/css/**");
        paths.add("/images/**");
        paths.add("/js/**");
        //excludePathPatterns放行的路径 addPathPatterns拦截的路径
        registry.addInterceptor(new UserInteceptor()).addPathPatterns("/**").excludePathPatterns(paths);
    }*/
}

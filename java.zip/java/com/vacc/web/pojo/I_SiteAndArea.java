package com.vacc.web.pojo;

public class I_SiteAndArea extends InoculationSite{

    private String provinceid;

    private String province;

    private String cityid;

    private String city;

    private String area;

    private String pca;  //包含省份市和地区

    public String getProvinceid() {
        return provinceid;
    }

    public void setProvinceid(String provinceid) {
        this.provinceid = provinceid;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCityid() {
        return cityid;
    }

    public void setCityid(String cityid) {
        this.cityid = cityid;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getPca() {
        return this.province+this.city+this.area;
    }

    public void setPca() {
        this.pca = this.province+this.city+this.area;
    }

    @Override
    public String toString() {
        return "I_SiteAndArea{" +
                "provinceid='" + provinceid + '\'' +
                ", province='" + province + '\'' +
                ", cityid='" + cityid + '\'' +
                ", city='" + city + '\'' +
                ", area='" + area + '\'' +
                ", pca='" + pca + '\'' +
                '}';
    }
}

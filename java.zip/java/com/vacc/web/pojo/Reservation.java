package com.vacc.web.pojo;

import java.util.Date;

public class Reservation {
    private Integer id;

    private Integer vaccinesid;

    private String vaccinesname;

    private Integer inoculationid;

    private String inoculationname;

    private Date starttime;

    private Date endtime;

    private Date reservationtime;

    private Integer userid;

    private Integer status;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getVaccinesid() {
        return vaccinesid;
    }

    public void setVaccinesid(Integer vaccinesid) {
        this.vaccinesid = vaccinesid;
    }

    public String getVaccinesname() {
        return vaccinesname;
    }

    public void setVaccinesname(String vaccinesname) {
        this.vaccinesname = vaccinesname == null ? null : vaccinesname.trim();
    }

    public Integer getInoculationid() {
        return inoculationid;
    }

    public void setInoculationid(Integer inoculationid) {
        this.inoculationid = inoculationid;
    }

    public String getInoculationname() {
        return inoculationname;
    }

    public void setInoculationname(String inoculationname) {
        this.inoculationname = inoculationname == null ? null : inoculationname.trim();
    }

    public Date getStarttime() {
        return starttime;
    }

    public void setStarttime(Date starttime) {
        this.starttime = starttime;
    }

    public Date getEndtime() {
        return endtime;
    }

    public void setEndtime(Date endtime) {
        this.endtime = endtime;
    }

    public Date getReservationtime() {
        return reservationtime;
    }

    public void setReservationtime(Date reservationtime) {
        this.reservationtime = reservationtime;
    }

    public Integer getUserid() {
        return userid;
    }

    public void setUserid(Integer userid) {
        this.userid = userid;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Reservation{" +
                "id=" + id +
                ", vaccinesid=" + vaccinesid +
                ", vaccinesname='" + vaccinesname + '\'' +
                ", inoculationid=" + inoculationid +
                ", inoculationname='" + inoculationname + '\'' +
                ", starttime=" + starttime +
                ", endtime=" + endtime +
                ", reservationtime=" + reservationtime +
                ", userid=" + userid +
                ", status=" + status +
                '}';
    }
}
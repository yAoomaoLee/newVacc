package com.vacc.web.pojo;

import java.util.Date;

public class InoculationHistory2 {

    private Long historyid;

    private Integer num;

    public Integer getNum() {
        return num;
    }

    public void setNum(Integer num) {
        this.num = num;
    }

    private String vaccinesname;

    private String inoculationname;

    private Date inoculationTime;

    public Long getHistoryid() {
        return historyid;
    }

    public void setHistoryid(Long historyid) {
        this.historyid = historyid;
    }

    public String getVaccinesname() {
        return vaccinesname;
    }

    public void setVaccinesname(String vaccinesname) {
        this.vaccinesname = vaccinesname;
    }

    public String getInoculationname() {
        return inoculationname;
    }

    public void setInoculationname(String inoculationname) {
        this.inoculationname = inoculationname;
    }

    public Date getInoculationTime() {
        return inoculationTime;
    }

    public void setInoculationTime(Date inoculationTime) {
        this.inoculationTime = inoculationTime;
    }

    @Override
    public String toString() {
        return "InoculationHistory2{" +
                "historyid=" + historyid +
                ", num=" + num +
                ", vaccinesname='" + vaccinesname + '\'' +
                ", inoculationname='" + inoculationname + '\'' +
                ", inoculationTime=" + inoculationTime +
                '}';
    }
}
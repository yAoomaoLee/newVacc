package com.vacc.web.pojo;

import java.util.Date;

public class InoculationHistory {
    private Long historyid;

    private Integer num;

    private Long vaccinesid;

    private Long inoculationid;

    private Date inoculationTime;

    private Long userid;

    public Long getHistoryid() {
        return historyid;
    }

    public void setHistoryid(Long historyid) {
        this.historyid = historyid;
    }

    public Integer getNum() {
        return num;
    }

    public void setNum(Integer num) {
        this.num = num;
    }

    public Long getVaccinesid() {
        return vaccinesid;
    }

    public void setVaccinesid(Long vaccinesid) {
        this.vaccinesid = vaccinesid;
    }

    public Long getInoculationid() {
        return inoculationid;
    }

    public void setInoculationid(Long inoculationid) {
        this.inoculationid = inoculationid;
    }

    public Date getInoculationTime() {
        return inoculationTime;
    }

    public void setInoculationTime(Date inoculationTime) {
        this.inoculationTime = inoculationTime;
    }

    public Long getUserid() {
        return userid;
    }

    public void setUserid(Long userid) {
        this.userid = userid;
    }

    @Override
    public String toString() {
        return "InoculationHistory{" +
                "historyid=" + historyid +
                ", num=" + num +
                ", vaccinesid=" + vaccinesid +
                ", inoculationid=" + inoculationid +
                ", inoculationTime=" + inoculationTime +
                ", userid=" + userid +
                '}';
    }
}
package com.vacc.web.pojo;

import java.util.Date;

public class InoculationSite {
    private Long inoculationid;

    private Integer areaid;

    private String detailedAddress;

    private String inoculationname;

    private Date starttime;

    private Date endtime;

    public Long getInoculationid() {
        return inoculationid;
    }

    public void setInoculationid(Long inoculationid) {
        this.inoculationid = inoculationid;
    }

    public Integer getAreaid() {
        return areaid;
    }

    public void setAreaid(Integer areaid) {
        this.areaid = areaid;
    }

    public String getDetailedAddress() {
        return detailedAddress;
    }

    public void setDetailedAddress(String detailedAddress) {
        this.detailedAddress = detailedAddress == null ? null : detailedAddress.trim();
    }

    public String getInoculationname() {
        return inoculationname;
    }

    public void setInoculationname(String inoculationname) {
        this.inoculationname = inoculationname == null ? null : inoculationname.trim();
    }

    public Date getStarttime() {
        return starttime;
    }

    public void setStarttime(Date starttime) {
        this.starttime = starttime;
    }

    public Date getEndtime() {
        return endtime;
    }

    public void setEndtime(Date endtime) {
        this.endtime = endtime;
    }

    @Override
    public String toString() {
        return "InoculationSite{" +
                "inoculationid=" + inoculationid +
                ", areaid=" + areaid +
                ", detailedAddress='" + detailedAddress + '\'' +
                ", inoculationname='" + inoculationname + '\'' +
                ", starttime=" + starttime +
                ", endtime=" + endtime +
                '}';
    }
}
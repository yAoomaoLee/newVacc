package com.vacc.web.pojo;

import java.util.Date;

public class Healthreport {
    private Integer id;

    private Date reportingtime;

    private String cough;

    private String temperature;

    private String departurearea;

    private String arrivalarea;

    private String address;

    private Long userid;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Date getReportingtime() {
        return reportingtime;
    }

    public void setReportingtime(Date reportingtime) {
        this.reportingtime = reportingtime;
    }

    public String getCough() {
        return cough;
    }

    public void setCough(String cough) {
        this.cough = cough == null ? null : cough.trim();
    }

    public String getTemperature() {
        return temperature;
    }

    public void setTemperature(String temperature) {
        this.temperature = temperature == null ? null : temperature.trim();
    }

    public String getDeparturearea() {
        return departurearea;
    }

    public void setDeparturearea(String departurearea) {
        this.departurearea = departurearea == null ? null : departurearea.trim();
    }

    public String getArrivalarea() {
        return arrivalarea;
    }

    public void setArrivalarea(String arrivalarea) {
        this.arrivalarea = arrivalarea == null ? null : arrivalarea.trim();
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address == null ? null : address.trim();
    }

    public Long getUserid() {
        return userid;
    }

    public void setUserid(Long userid) {
        this.userid = userid;
    }

    @Override
    public String toString() {
        return "Healthreport{" +
                "id=" + id +
                ", reportingtime=" + reportingtime +
                ", cough='" + cough + '\'' +
                ", temperature='" + temperature + '\'' +
                ", departurearea='" + departurearea + '\'' +
                ", arrivalarea='" + arrivalarea + '\'' +
                ", address='" + address + '\'' +
                ", userid=" + userid +
                '}';
    }
}
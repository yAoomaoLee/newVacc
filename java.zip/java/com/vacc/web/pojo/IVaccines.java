package com.vacc.web.pojo;

public class IVaccines {
    private int id;

    private Long inoculationid;

    private Long vaccinesid;

    private Integer inventory;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Long getInoculationid() {
        return inoculationid;
    }

    public void setInoculationid(Long inoculationid) {
        this.inoculationid = inoculationid;
    }

    public Long getVaccinesid() {
        return vaccinesid;
    }

    public void setVaccinesid(Long vaccinesid) {
        this.vaccinesid = vaccinesid;
    }

    public Integer getInventory() {
        return inventory;
    }

    public void setInventory(Integer inventory) {
        this.inventory = inventory;
    }
}
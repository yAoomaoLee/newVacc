package com.vacc.web.pojo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ReservationExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public ReservationExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("id is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("id is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(Integer value) {
            addCriterion("id =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(Integer value) {
            addCriterion("id <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(Integer value) {
            addCriterion("id >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("id >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(Integer value) {
            addCriterion("id <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(Integer value) {
            addCriterion("id <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<Integer> values) {
            addCriterion("id in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<Integer> values) {
            addCriterion("id not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(Integer value1, Integer value2) {
            addCriterion("id between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(Integer value1, Integer value2) {
            addCriterion("id not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andVaccinesidIsNull() {
            addCriterion("vaccinesId is null");
            return (Criteria) this;
        }

        public Criteria andVaccinesidIsNotNull() {
            addCriterion("vaccinesId is not null");
            return (Criteria) this;
        }

        public Criteria andVaccinesidEqualTo(Integer value) {
            addCriterion("vaccinesId =", value, "vaccinesid");
            return (Criteria) this;
        }

        public Criteria andVaccinesidNotEqualTo(Integer value) {
            addCriterion("vaccinesId <>", value, "vaccinesid");
            return (Criteria) this;
        }

        public Criteria andVaccinesidGreaterThan(Integer value) {
            addCriterion("vaccinesId >", value, "vaccinesid");
            return (Criteria) this;
        }

        public Criteria andVaccinesidGreaterThanOrEqualTo(Integer value) {
            addCriterion("vaccinesId >=", value, "vaccinesid");
            return (Criteria) this;
        }

        public Criteria andVaccinesidLessThan(Integer value) {
            addCriterion("vaccinesId <", value, "vaccinesid");
            return (Criteria) this;
        }

        public Criteria andVaccinesidLessThanOrEqualTo(Integer value) {
            addCriterion("vaccinesId <=", value, "vaccinesid");
            return (Criteria) this;
        }

        public Criteria andVaccinesidIn(List<Integer> values) {
            addCriterion("vaccinesId in", values, "vaccinesid");
            return (Criteria) this;
        }

        public Criteria andVaccinesidNotIn(List<Integer> values) {
            addCriterion("vaccinesId not in", values, "vaccinesid");
            return (Criteria) this;
        }

        public Criteria andVaccinesidBetween(Integer value1, Integer value2) {
            addCriterion("vaccinesId between", value1, value2, "vaccinesid");
            return (Criteria) this;
        }

        public Criteria andVaccinesidNotBetween(Integer value1, Integer value2) {
            addCriterion("vaccinesId not between", value1, value2, "vaccinesid");
            return (Criteria) this;
        }

        public Criteria andVaccinesnameIsNull() {
            addCriterion("vaccinesname is null");
            return (Criteria) this;
        }

        public Criteria andVaccinesnameIsNotNull() {
            addCriterion("vaccinesname is not null");
            return (Criteria) this;
        }

        public Criteria andVaccinesnameEqualTo(String value) {
            addCriterion("vaccinesname =", value, "vaccinesname");
            return (Criteria) this;
        }

        public Criteria andVaccinesnameNotEqualTo(String value) {
            addCriterion("vaccinesname <>", value, "vaccinesname");
            return (Criteria) this;
        }

        public Criteria andVaccinesnameGreaterThan(String value) {
            addCriterion("vaccinesname >", value, "vaccinesname");
            return (Criteria) this;
        }

        public Criteria andVaccinesnameGreaterThanOrEqualTo(String value) {
            addCriterion("vaccinesname >=", value, "vaccinesname");
            return (Criteria) this;
        }

        public Criteria andVaccinesnameLessThan(String value) {
            addCriterion("vaccinesname <", value, "vaccinesname");
            return (Criteria) this;
        }

        public Criteria andVaccinesnameLessThanOrEqualTo(String value) {
            addCriterion("vaccinesname <=", value, "vaccinesname");
            return (Criteria) this;
        }

        public Criteria andVaccinesnameLike(String value) {
            addCriterion("vaccinesname like", value, "vaccinesname");
            return (Criteria) this;
        }

        public Criteria andVaccinesnameNotLike(String value) {
            addCriterion("vaccinesname not like", value, "vaccinesname");
            return (Criteria) this;
        }

        public Criteria andVaccinesnameIn(List<String> values) {
            addCriterion("vaccinesname in", values, "vaccinesname");
            return (Criteria) this;
        }

        public Criteria andVaccinesnameNotIn(List<String> values) {
            addCriterion("vaccinesname not in", values, "vaccinesname");
            return (Criteria) this;
        }

        public Criteria andVaccinesnameBetween(String value1, String value2) {
            addCriterion("vaccinesname between", value1, value2, "vaccinesname");
            return (Criteria) this;
        }

        public Criteria andVaccinesnameNotBetween(String value1, String value2) {
            addCriterion("vaccinesname not between", value1, value2, "vaccinesname");
            return (Criteria) this;
        }

        public Criteria andInoculationidIsNull() {
            addCriterion("InoculationId is null");
            return (Criteria) this;
        }

        public Criteria andInoculationidIsNotNull() {
            addCriterion("InoculationId is not null");
            return (Criteria) this;
        }

        public Criteria andInoculationidEqualTo(Integer value) {
            addCriterion("InoculationId =", value, "inoculationid");
            return (Criteria) this;
        }

        public Criteria andInoculationidNotEqualTo(Integer value) {
            addCriterion("InoculationId <>", value, "inoculationid");
            return (Criteria) this;
        }

        public Criteria andInoculationidGreaterThan(Integer value) {
            addCriterion("InoculationId >", value, "inoculationid");
            return (Criteria) this;
        }

        public Criteria andInoculationidGreaterThanOrEqualTo(Integer value) {
            addCriterion("InoculationId >=", value, "inoculationid");
            return (Criteria) this;
        }

        public Criteria andInoculationidLessThan(Integer value) {
            addCriterion("InoculationId <", value, "inoculationid");
            return (Criteria) this;
        }

        public Criteria andInoculationidLessThanOrEqualTo(Integer value) {
            addCriterion("InoculationId <=", value, "inoculationid");
            return (Criteria) this;
        }

        public Criteria andInoculationidIn(List<Integer> values) {
            addCriterion("InoculationId in", values, "inoculationid");
            return (Criteria) this;
        }

        public Criteria andInoculationidNotIn(List<Integer> values) {
            addCriterion("InoculationId not in", values, "inoculationid");
            return (Criteria) this;
        }

        public Criteria andInoculationidBetween(Integer value1, Integer value2) {
            addCriterion("InoculationId between", value1, value2, "inoculationid");
            return (Criteria) this;
        }

        public Criteria andInoculationidNotBetween(Integer value1, Integer value2) {
            addCriterion("InoculationId not between", value1, value2, "inoculationid");
            return (Criteria) this;
        }

        public Criteria andInoculationnameIsNull() {
            addCriterion("inoculationname is null");
            return (Criteria) this;
        }

        public Criteria andInoculationnameIsNotNull() {
            addCriterion("inoculationname is not null");
            return (Criteria) this;
        }

        public Criteria andInoculationnameEqualTo(String value) {
            addCriterion("inoculationname =", value, "inoculationname");
            return (Criteria) this;
        }

        public Criteria andInoculationnameNotEqualTo(String value) {
            addCriterion("inoculationname <>", value, "inoculationname");
            return (Criteria) this;
        }

        public Criteria andInoculationnameGreaterThan(String value) {
            addCriterion("inoculationname >", value, "inoculationname");
            return (Criteria) this;
        }

        public Criteria andInoculationnameGreaterThanOrEqualTo(String value) {
            addCriterion("inoculationname >=", value, "inoculationname");
            return (Criteria) this;
        }

        public Criteria andInoculationnameLessThan(String value) {
            addCriterion("inoculationname <", value, "inoculationname");
            return (Criteria) this;
        }

        public Criteria andInoculationnameLessThanOrEqualTo(String value) {
            addCriterion("inoculationname <=", value, "inoculationname");
            return (Criteria) this;
        }

        public Criteria andInoculationnameLike(String value) {
            addCriterion("inoculationname like", value, "inoculationname");
            return (Criteria) this;
        }

        public Criteria andInoculationnameNotLike(String value) {
            addCriterion("inoculationname not like", value, "inoculationname");
            return (Criteria) this;
        }

        public Criteria andInoculationnameIn(List<String> values) {
            addCriterion("inoculationname in", values, "inoculationname");
            return (Criteria) this;
        }

        public Criteria andInoculationnameNotIn(List<String> values) {
            addCriterion("inoculationname not in", values, "inoculationname");
            return (Criteria) this;
        }

        public Criteria andInoculationnameBetween(String value1, String value2) {
            addCriterion("inoculationname between", value1, value2, "inoculationname");
            return (Criteria) this;
        }

        public Criteria andInoculationnameNotBetween(String value1, String value2) {
            addCriterion("inoculationname not between", value1, value2, "inoculationname");
            return (Criteria) this;
        }

        public Criteria andStarttimeIsNull() {
            addCriterion("starttime is null");
            return (Criteria) this;
        }

        public Criteria andStarttimeIsNotNull() {
            addCriterion("starttime is not null");
            return (Criteria) this;
        }

        public Criteria andStarttimeEqualTo(Date value) {
            addCriterion("starttime =", value, "starttime");
            return (Criteria) this;
        }

        public Criteria andStarttimeNotEqualTo(Date value) {
            addCriterion("starttime <>", value, "starttime");
            return (Criteria) this;
        }

        public Criteria andStarttimeGreaterThan(Date value) {
            addCriterion("starttime >", value, "starttime");
            return (Criteria) this;
        }

        public Criteria andStarttimeGreaterThanOrEqualTo(Date value) {
            addCriterion("starttime >=", value, "starttime");
            return (Criteria) this;
        }

        public Criteria andStarttimeLessThan(Date value) {
            addCriterion("starttime <", value, "starttime");
            return (Criteria) this;
        }

        public Criteria andStarttimeLessThanOrEqualTo(Date value) {
            addCriterion("starttime <=", value, "starttime");
            return (Criteria) this;
        }

        public Criteria andStarttimeIn(List<Date> values) {
            addCriterion("starttime in", values, "starttime");
            return (Criteria) this;
        }

        public Criteria andStarttimeNotIn(List<Date> values) {
            addCriterion("starttime not in", values, "starttime");
            return (Criteria) this;
        }

        public Criteria andStarttimeBetween(Date value1, Date value2) {
            addCriterion("starttime between", value1, value2, "starttime");
            return (Criteria) this;
        }

        public Criteria andStarttimeNotBetween(Date value1, Date value2) {
            addCriterion("starttime not between", value1, value2, "starttime");
            return (Criteria) this;
        }

        public Criteria andEndtimeIsNull() {
            addCriterion("endtime is null");
            return (Criteria) this;
        }

        public Criteria andEndtimeIsNotNull() {
            addCriterion("endtime is not null");
            return (Criteria) this;
        }

        public Criteria andEndtimeEqualTo(Date value) {
            addCriterion("endtime =", value, "endtime");
            return (Criteria) this;
        }

        public Criteria andEndtimeNotEqualTo(Date value) {
            addCriterion("endtime <>", value, "endtime");
            return (Criteria) this;
        }

        public Criteria andEndtimeGreaterThan(Date value) {
            addCriterion("endtime >", value, "endtime");
            return (Criteria) this;
        }

        public Criteria andEndtimeGreaterThanOrEqualTo(Date value) {
            addCriterion("endtime >=", value, "endtime");
            return (Criteria) this;
        }

        public Criteria andEndtimeLessThan(Date value) {
            addCriterion("endtime <", value, "endtime");
            return (Criteria) this;
        }

        public Criteria andEndtimeLessThanOrEqualTo(Date value) {
            addCriterion("endtime <=", value, "endtime");
            return (Criteria) this;
        }

        public Criteria andEndtimeIn(List<Date> values) {
            addCriterion("endtime in", values, "endtime");
            return (Criteria) this;
        }

        public Criteria andEndtimeNotIn(List<Date> values) {
            addCriterion("endtime not in", values, "endtime");
            return (Criteria) this;
        }

        public Criteria andEndtimeBetween(Date value1, Date value2) {
            addCriterion("endtime between", value1, value2, "endtime");
            return (Criteria) this;
        }

        public Criteria andEndtimeNotBetween(Date value1, Date value2) {
            addCriterion("endtime not between", value1, value2, "endtime");
            return (Criteria) this;
        }

        public Criteria andReservationtimeIsNull() {
            addCriterion("reservationTime is null");
            return (Criteria) this;
        }

        public Criteria andReservationtimeIsNotNull() {
            addCriterion("reservationTime is not null");
            return (Criteria) this;
        }

        public Criteria andReservationtimeEqualTo(Date value) {
            addCriterion("reservationTime =", value, "reservationtime");
            return (Criteria) this;
        }

        public Criteria andReservationtimeNotEqualTo(Date value) {
            addCriterion("reservationTime <>", value, "reservationtime");
            return (Criteria) this;
        }

        public Criteria andReservationtimeGreaterThan(Date value) {
            addCriterion("reservationTime >", value, "reservationtime");
            return (Criteria) this;
        }

        public Criteria andReservationtimeGreaterThanOrEqualTo(Date value) {
            addCriterion("reservationTime >=", value, "reservationtime");
            return (Criteria) this;
        }

        public Criteria andReservationtimeLessThan(Date value) {
            addCriterion("reservationTime <", value, "reservationtime");
            return (Criteria) this;
        }

        public Criteria andReservationtimeLessThanOrEqualTo(Date value) {
            addCriterion("reservationTime <=", value, "reservationtime");
            return (Criteria) this;
        }

        public Criteria andReservationtimeIn(List<Date> values) {
            addCriterion("reservationTime in", values, "reservationtime");
            return (Criteria) this;
        }

        public Criteria andReservationtimeNotIn(List<Date> values) {
            addCriterion("reservationTime not in", values, "reservationtime");
            return (Criteria) this;
        }

        public Criteria andReservationtimeBetween(Date value1, Date value2) {
            addCriterion("reservationTime between", value1, value2, "reservationtime");
            return (Criteria) this;
        }

        public Criteria andReservationtimeNotBetween(Date value1, Date value2) {
            addCriterion("reservationTime not between", value1, value2, "reservationtime");
            return (Criteria) this;
        }

        public Criteria andUseridIsNull() {
            addCriterion("userId is null");
            return (Criteria) this;
        }

        public Criteria andUseridIsNotNull() {
            addCriterion("userId is not null");
            return (Criteria) this;
        }

        public Criteria andUseridEqualTo(Integer value) {
            addCriterion("userId =", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridNotEqualTo(Integer value) {
            addCriterion("userId <>", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridGreaterThan(Integer value) {
            addCriterion("userId >", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridGreaterThanOrEqualTo(Integer value) {
            addCriterion("userId >=", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridLessThan(Integer value) {
            addCriterion("userId <", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridLessThanOrEqualTo(Integer value) {
            addCriterion("userId <=", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridIn(List<Integer> values) {
            addCriterion("userId in", values, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridNotIn(List<Integer> values) {
            addCriterion("userId not in", values, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridBetween(Integer value1, Integer value2) {
            addCriterion("userId between", value1, value2, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridNotBetween(Integer value1, Integer value2) {
            addCriterion("userId not between", value1, value2, "userid");
            return (Criteria) this;
        }

        public Criteria andStatusIsNull() {
            addCriterion("status is null");
            return (Criteria) this;
        }

        public Criteria andStatusIsNotNull() {
            addCriterion("status is not null");
            return (Criteria) this;
        }

        public Criteria andStatusEqualTo(Integer value) {
            addCriterion("status =", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotEqualTo(Integer value) {
            addCriterion("status <>", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThan(Integer value) {
            addCriterion("status >", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("status >=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThan(Integer value) {
            addCriterion("status <", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThanOrEqualTo(Integer value) {
            addCriterion("status <=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusIn(List<Integer> values) {
            addCriterion("status in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotIn(List<Integer> values) {
            addCriterion("status not in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusBetween(Integer value1, Integer value2) {
            addCriterion("status between", value1, value2, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotBetween(Integer value1, Integer value2) {
            addCriterion("status not between", value1, value2, "status");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}
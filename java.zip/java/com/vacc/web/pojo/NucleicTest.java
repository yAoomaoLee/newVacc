package com.vacc.web.pojo;

import java.util.Date;

public class NucleicTest {
    private Long id;

    private Date time;

    private Date endtime;

    private Byte result;

    private Long userid;

    private Long detectionid;

    private DetectionPoint detectionPoint;

    private User user;

    public NucleicTest(Long id, Date endtime, Long detectionid, Byte result) {
        this.id = id;
        this.endtime = endtime;
        this.result = result;
        this.detectionid = detectionid;
    }

    public NucleicTest() {
    }

    public DetectionPoint getDetectionPoint() {
        return detectionPoint;
    }

    public void setDetectionPoint(DetectionPoint detectionPoint) {
        this.detectionPoint = detectionPoint;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    public Date getEndtime() {
        return endtime;
    }

    public void setEndtime(Date endtime) {
        this.endtime = endtime;
    }

    public Byte getResult() {
        return result;
    }

    public void setResult(Byte result) {
        this.result = result;
    }

    public Long getUserid() {
        return userid;
    }

    public void setUserid(Long userid) {
        this.userid = userid;
    }

    public Long getDetectionid() {
        return detectionid;
    }

    public void setDetectionid(Long detectionid) {
        this.detectionid = detectionid;
    }
}
package com.vacc.web.pojo;

public class Vaccines {
    private Long vaccinesid;

    private String vaccinesname;

    private String manufactor;

    private String vacctype;

    private String describes;

    @Override
    public String toString() {
        return "Vaccines{" +
                "vaccinesid=" + vaccinesid +
                ", vaccinesname='" + vaccinesname + '\'' +
                ", manufactor='" + manufactor + '\'' +
                ", vacctype='" + vacctype + '\'' +
                ", describes='" + describes + '\'' +
                '}';
    }

    public Long getVaccinesid() {
        return vaccinesid;
    }

    public void setVaccinesid(Long vaccinesid) {
        this.vaccinesid = vaccinesid;
    }

    public String getVaccinesname() {
        return vaccinesname;
    }

    public void setVaccinesname(String vaccinesname) {
        this.vaccinesname = vaccinesname == null ? null : vaccinesname.trim();
    }

    public String getManufactor() {
        return manufactor;
    }

    public void setManufactor(String manufactor) {
        this.manufactor = manufactor == null ? null : manufactor.trim();
    }

    public String getVacctype() {
        return vacctype;
    }

    public void setVacctype(String vacctype) {
        this.vacctype = vacctype == null ? null : vacctype.trim();
    }

    public String getDescribes() {
        return describes;
    }

    public void setDescribes(String describes) {
        this.describes = describes == null ? null : describes.trim();
    }
}
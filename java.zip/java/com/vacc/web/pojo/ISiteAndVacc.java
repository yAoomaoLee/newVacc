package com.vacc.web.pojo;

import java.util.Date;

public class ISiteAndVacc extends IVaccines{

    private String vaccinesname;

    private String manufactor;

    private String inoculationname;

    private Date starttime;

    private Date endtime;

    public String getVaccinesname() {
        return vaccinesname;
    }

    public void setVaccinesname(String vaccinesname) {
        this.vaccinesname = vaccinesname;
    }

    public String getManufactor() {
        return manufactor;
    }

    public void setManufactor(String manufactor) {
        this.manufactor = manufactor;
    }

    public String getInoculationname() {
        return inoculationname;
    }

    public void setInoculationname(String inoculationname) {
        this.inoculationname = inoculationname;
    }

    public Date getStarttime() {
        return starttime;
    }

    public void setStarttime(Date starttime) {
        this.starttime = starttime;
    }

    public Date getEndtime() {
        return endtime;
    }

    public void setEndtime(Date endtime) {
        this.endtime = endtime;
    }

    @Override
    public String toString() {
        return "ISiteAndVacc{" +
                "vaccinesname='" + vaccinesname + '\'' +
                ", manufactor='" + manufactor + '\'' +
                ", inoculationname='" + inoculationname + '\'' +
                ", starttime=" + starttime +
                ", endtime=" + endtime +
                '}';
    }
}

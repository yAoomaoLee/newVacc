package com.vacc.web.pojo;

import java.util.ArrayList;
import java.util.List;

public class VaccinesExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public VaccinesExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andVaccinesidIsNull() {
            addCriterion("vaccinesId is null");
            return (Criteria) this;
        }

        public Criteria andVaccinesidIsNotNull() {
            addCriterion("vaccinesId is not null");
            return (Criteria) this;
        }

        public Criteria andVaccinesidEqualTo(Long value) {
            addCriterion("vaccinesId =", value, "vaccinesid");
            return (Criteria) this;
        }

        public Criteria andVaccinesidNotEqualTo(Long value) {
            addCriterion("vaccinesId <>", value, "vaccinesid");
            return (Criteria) this;
        }

        public Criteria andVaccinesidGreaterThan(Long value) {
            addCriterion("vaccinesId >", value, "vaccinesid");
            return (Criteria) this;
        }

        public Criteria andVaccinesidGreaterThanOrEqualTo(Long value) {
            addCriterion("vaccinesId >=", value, "vaccinesid");
            return (Criteria) this;
        }

        public Criteria andVaccinesidLessThan(Long value) {
            addCriterion("vaccinesId <", value, "vaccinesid");
            return (Criteria) this;
        }

        public Criteria andVaccinesidLessThanOrEqualTo(Long value) {
            addCriterion("vaccinesId <=", value, "vaccinesid");
            return (Criteria) this;
        }

        public Criteria andVaccinesidIn(List<Long> values) {
            addCriterion("vaccinesId in", values, "vaccinesid");
            return (Criteria) this;
        }

        public Criteria andVaccinesidNotIn(List<Long> values) {
            addCriterion("vaccinesId not in", values, "vaccinesid");
            return (Criteria) this;
        }

        public Criteria andVaccinesidBetween(Long value1, Long value2) {
            addCriterion("vaccinesId between", value1, value2, "vaccinesid");
            return (Criteria) this;
        }

        public Criteria andVaccinesidNotBetween(Long value1, Long value2) {
            addCriterion("vaccinesId not between", value1, value2, "vaccinesid");
            return (Criteria) this;
        }

        public Criteria andVaccinesnameIsNull() {
            addCriterion("vaccinesName is null");
            return (Criteria) this;
        }

        public Criteria andVaccinesnameIsNotNull() {
            addCriterion("vaccinesName is not null");
            return (Criteria) this;
        }

        public Criteria andVaccinesnameEqualTo(String value) {
            addCriterion("vaccinesName =", value, "vaccinesname");
            return (Criteria) this;
        }

        public Criteria andVaccinesnameNotEqualTo(String value) {
            addCriterion("vaccinesName <>", value, "vaccinesname");
            return (Criteria) this;
        }

        public Criteria andVaccinesnameGreaterThan(String value) {
            addCriterion("vaccinesName >", value, "vaccinesname");
            return (Criteria) this;
        }

        public Criteria andVaccinesnameGreaterThanOrEqualTo(String value) {
            addCriterion("vaccinesName >=", value, "vaccinesname");
            return (Criteria) this;
        }

        public Criteria andVaccinesnameLessThan(String value) {
            addCriterion("vaccinesName <", value, "vaccinesname");
            return (Criteria) this;
        }

        public Criteria andVaccinesnameLessThanOrEqualTo(String value) {
            addCriterion("vaccinesName <=", value, "vaccinesname");
            return (Criteria) this;
        }

        public Criteria andVaccinesnameLike(String value) {
            addCriterion("vaccinesName like", value, "vaccinesname");
            return (Criteria) this;
        }

        public Criteria andVaccinesnameNotLike(String value) {
            addCriterion("vaccinesName not like", value, "vaccinesname");
            return (Criteria) this;
        }

        public Criteria andVaccinesnameIn(List<String> values) {
            addCriterion("vaccinesName in", values, "vaccinesname");
            return (Criteria) this;
        }

        public Criteria andVaccinesnameNotIn(List<String> values) {
            addCriterion("vaccinesName not in", values, "vaccinesname");
            return (Criteria) this;
        }

        public Criteria andVaccinesnameBetween(String value1, String value2) {
            addCriterion("vaccinesName between", value1, value2, "vaccinesname");
            return (Criteria) this;
        }

        public Criteria andVaccinesnameNotBetween(String value1, String value2) {
            addCriterion("vaccinesName not between", value1, value2, "vaccinesname");
            return (Criteria) this;
        }

        public Criteria andManufactorIsNull() {
            addCriterion("manufactor is null");
            return (Criteria) this;
        }

        public Criteria andManufactorIsNotNull() {
            addCriterion("manufactor is not null");
            return (Criteria) this;
        }

        public Criteria andManufactorEqualTo(String value) {
            addCriterion("manufactor =", value, "manufactor");
            return (Criteria) this;
        }

        public Criteria andManufactorNotEqualTo(String value) {
            addCriterion("manufactor <>", value, "manufactor");
            return (Criteria) this;
        }

        public Criteria andManufactorGreaterThan(String value) {
            addCriterion("manufactor >", value, "manufactor");
            return (Criteria) this;
        }

        public Criteria andManufactorGreaterThanOrEqualTo(String value) {
            addCriterion("manufactor >=", value, "manufactor");
            return (Criteria) this;
        }

        public Criteria andManufactorLessThan(String value) {
            addCriterion("manufactor <", value, "manufactor");
            return (Criteria) this;
        }

        public Criteria andManufactorLessThanOrEqualTo(String value) {
            addCriterion("manufactor <=", value, "manufactor");
            return (Criteria) this;
        }

        public Criteria andManufactorLike(String value) {
            addCriterion("manufactor like", value, "manufactor");
            return (Criteria) this;
        }

        public Criteria andManufactorNotLike(String value) {
            addCriterion("manufactor not like", value, "manufactor");
            return (Criteria) this;
        }

        public Criteria andManufactorIn(List<String> values) {
            addCriterion("manufactor in", values, "manufactor");
            return (Criteria) this;
        }

        public Criteria andManufactorNotIn(List<String> values) {
            addCriterion("manufactor not in", values, "manufactor");
            return (Criteria) this;
        }

        public Criteria andManufactorBetween(String value1, String value2) {
            addCriterion("manufactor between", value1, value2, "manufactor");
            return (Criteria) this;
        }

        public Criteria andManufactorNotBetween(String value1, String value2) {
            addCriterion("manufactor not between", value1, value2, "manufactor");
            return (Criteria) this;
        }

        public Criteria andVacctypeIsNull() {
            addCriterion("vacctype is null");
            return (Criteria) this;
        }

        public Criteria andVacctypeIsNotNull() {
            addCriterion("vacctype is not null");
            return (Criteria) this;
        }

        public Criteria andVacctypeEqualTo(String value) {
            addCriterion("vacctype =", value, "vacctype");
            return (Criteria) this;
        }

        public Criteria andVacctypeNotEqualTo(String value) {
            addCriterion("vacctype <>", value, "vacctype");
            return (Criteria) this;
        }

        public Criteria andVacctypeGreaterThan(String value) {
            addCriterion("vacctype >", value, "vacctype");
            return (Criteria) this;
        }

        public Criteria andVacctypeGreaterThanOrEqualTo(String value) {
            addCriterion("vacctype >=", value, "vacctype");
            return (Criteria) this;
        }

        public Criteria andVacctypeLessThan(String value) {
            addCriterion("vacctype <", value, "vacctype");
            return (Criteria) this;
        }

        public Criteria andVacctypeLessThanOrEqualTo(String value) {
            addCriterion("vacctype <=", value, "vacctype");
            return (Criteria) this;
        }

        public Criteria andVacctypeLike(String value) {
            addCriterion("vacctype like", value, "vacctype");
            return (Criteria) this;
        }

        public Criteria andVacctypeNotLike(String value) {
            addCriterion("vacctype not like", value, "vacctype");
            return (Criteria) this;
        }

        public Criteria andVacctypeIn(List<String> values) {
            addCriterion("vacctype in", values, "vacctype");
            return (Criteria) this;
        }

        public Criteria andVacctypeNotIn(List<String> values) {
            addCriterion("vacctype not in", values, "vacctype");
            return (Criteria) this;
        }

        public Criteria andVacctypeBetween(String value1, String value2) {
            addCriterion("vacctype between", value1, value2, "vacctype");
            return (Criteria) this;
        }

        public Criteria andVacctypeNotBetween(String value1, String value2) {
            addCriterion("vacctype not between", value1, value2, "vacctype");
            return (Criteria) this;
        }

        public Criteria andDescribesIsNull() {
            addCriterion("describes is null");
            return (Criteria) this;
        }

        public Criteria andDescribesIsNotNull() {
            addCriterion("describes is not null");
            return (Criteria) this;
        }

        public Criteria andDescribesEqualTo(String value) {
            addCriterion("describes =", value, "describes");
            return (Criteria) this;
        }

        public Criteria andDescribesNotEqualTo(String value) {
            addCriterion("describes <>", value, "describes");
            return (Criteria) this;
        }

        public Criteria andDescribesGreaterThan(String value) {
            addCriterion("describes >", value, "describes");
            return (Criteria) this;
        }

        public Criteria andDescribesGreaterThanOrEqualTo(String value) {
            addCriterion("describes >=", value, "describes");
            return (Criteria) this;
        }

        public Criteria andDescribesLessThan(String value) {
            addCriterion("describes <", value, "describes");
            return (Criteria) this;
        }

        public Criteria andDescribesLessThanOrEqualTo(String value) {
            addCriterion("describes <=", value, "describes");
            return (Criteria) this;
        }

        public Criteria andDescribesLike(String value) {
            addCriterion("describes like", value, "describes");
            return (Criteria) this;
        }

        public Criteria andDescribesNotLike(String value) {
            addCriterion("describes not like", value, "describes");
            return (Criteria) this;
        }

        public Criteria andDescribesIn(List<String> values) {
            addCriterion("describes in", values, "describes");
            return (Criteria) this;
        }

        public Criteria andDescribesNotIn(List<String> values) {
            addCriterion("describes not in", values, "describes");
            return (Criteria) this;
        }

        public Criteria andDescribesBetween(String value1, String value2) {
            addCriterion("describes between", value1, value2, "describes");
            return (Criteria) this;
        }

        public Criteria andDescribesNotBetween(String value1, String value2) {
            addCriterion("describes not between", value1, value2, "describes");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}
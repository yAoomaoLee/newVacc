package com.vacc.web.pojo;

import java.util.Date;

public class GeneralSampling {
    private Integer id;

    private String name;

    private String tel;

    private Integer documentType;

    private String documentNo;

    private String sex;

    private Date birthday;

    private String country;

    private Integer age;

    private String currentResidence;

    private String detailedAddress;

    private Integer crowdTypeid;

    private Integer inspectTypeid;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel == null ? null : tel.trim();
    }

    public Integer getDocumentType() {
        return documentType;
    }

    public void setDocumentType(Integer documentType) {
        this.documentType = documentType;
    }

    public String getDocumentNo() {
        return documentNo;
    }

    public void setDocumentNo(String documentNo) {
        this.documentNo = documentNo == null ? null : documentNo.trim();
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex == null ? null : sex.trim();
    }

    public Date getBirthday() {
        return birthday;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country == null ? null : country.trim();
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public String getCurrentResidence() {
        return currentResidence;
    }

    public void setCurrentResidence(String currentResidence) {
        this.currentResidence = currentResidence == null ? null : currentResidence.trim();
    }

    public String getDetailedAddress() {
        return detailedAddress;
    }

    public void setDetailedAddress(String detailedAddress) {
        this.detailedAddress = detailedAddress == null ? null : detailedAddress.trim();
    }

    public Integer getCrowdTypeid() {
        return crowdTypeid;
    }

    public void setCrowdTypeid(Integer crowdTypeid) {
        this.crowdTypeid = crowdTypeid;
    }

    public Integer getInspectTypeid() {
        return inspectTypeid;
    }

    public void setInspectTypeid(Integer inspectTypeid) {
        this.inspectTypeid = inspectTypeid;
    }
}
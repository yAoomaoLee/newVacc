package com.vacc.web.pojo;

public class CrowdType {
    private Integer id;

    private String crowdType;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCrowdType() {
        return crowdType;
    }

    public void setCrowdType(String crowdType) {
        this.crowdType = crowdType == null ? null : crowdType.trim();
    }
}
package com.vacc.web.pojo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class InoculationHistoryExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public InoculationHistoryExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andHistoryidIsNull() {
            addCriterion("historyId is null");
            return (Criteria) this;
        }

        public Criteria andHistoryidIsNotNull() {
            addCriterion("historyId is not null");
            return (Criteria) this;
        }

        public Criteria andHistoryidEqualTo(Long value) {
            addCriterion("historyId =", value, "historyid");
            return (Criteria) this;
        }

        public Criteria andHistoryidNotEqualTo(Long value) {
            addCriterion("historyId <>", value, "historyid");
            return (Criteria) this;
        }

        public Criteria andHistoryidGreaterThan(Long value) {
            addCriterion("historyId >", value, "historyid");
            return (Criteria) this;
        }

        public Criteria andHistoryidGreaterThanOrEqualTo(Long value) {
            addCriterion("historyId >=", value, "historyid");
            return (Criteria) this;
        }

        public Criteria andHistoryidLessThan(Long value) {
            addCriterion("historyId <", value, "historyid");
            return (Criteria) this;
        }

        public Criteria andHistoryidLessThanOrEqualTo(Long value) {
            addCriterion("historyId <=", value, "historyid");
            return (Criteria) this;
        }

        public Criteria andHistoryidIn(List<Long> values) {
            addCriterion("historyId in", values, "historyid");
            return (Criteria) this;
        }

        public Criteria andHistoryidNotIn(List<Long> values) {
            addCriterion("historyId not in", values, "historyid");
            return (Criteria) this;
        }

        public Criteria andHistoryidBetween(Long value1, Long value2) {
            addCriterion("historyId between", value1, value2, "historyid");
            return (Criteria) this;
        }

        public Criteria andHistoryidNotBetween(Long value1, Long value2) {
            addCriterion("historyId not between", value1, value2, "historyid");
            return (Criteria) this;
        }

        public Criteria andNumIsNull() {
            addCriterion("Num is null");
            return (Criteria) this;
        }

        public Criteria andNumIsNotNull() {
            addCriterion("Num is not null");
            return (Criteria) this;
        }

        public Criteria andNumEqualTo(Integer value) {
            addCriterion("Num =", value, "num");
            return (Criteria) this;
        }

        public Criteria andNumNotEqualTo(Integer value) {
            addCriterion("Num <>", value, "num");
            return (Criteria) this;
        }

        public Criteria andNumGreaterThan(Integer value) {
            addCriterion("Num >", value, "num");
            return (Criteria) this;
        }

        public Criteria andNumGreaterThanOrEqualTo(Integer value) {
            addCriterion("Num >=", value, "num");
            return (Criteria) this;
        }

        public Criteria andNumLessThan(Integer value) {
            addCriterion("Num <", value, "num");
            return (Criteria) this;
        }

        public Criteria andNumLessThanOrEqualTo(Integer value) {
            addCriterion("Num <=", value, "num");
            return (Criteria) this;
        }

        public Criteria andNumIn(List<Integer> values) {
            addCriterion("Num in", values, "num");
            return (Criteria) this;
        }

        public Criteria andNumNotIn(List<Integer> values) {
            addCriterion("Num not in", values, "num");
            return (Criteria) this;
        }

        public Criteria andNumBetween(Integer value1, Integer value2) {
            addCriterion("Num between", value1, value2, "num");
            return (Criteria) this;
        }

        public Criteria andNumNotBetween(Integer value1, Integer value2) {
            addCriterion("Num not between", value1, value2, "num");
            return (Criteria) this;
        }

        public Criteria andVaccinesidIsNull() {
            addCriterion("vaccinesId is null");
            return (Criteria) this;
        }

        public Criteria andVaccinesidIsNotNull() {
            addCriterion("vaccinesId is not null");
            return (Criteria) this;
        }

        public Criteria andVaccinesidEqualTo(Long value) {
            addCriterion("vaccinesId =", value, "vaccinesid");
            return (Criteria) this;
        }

        public Criteria andVaccinesidNotEqualTo(Long value) {
            addCriterion("vaccinesId <>", value, "vaccinesid");
            return (Criteria) this;
        }

        public Criteria andVaccinesidGreaterThan(Long value) {
            addCriterion("vaccinesId >", value, "vaccinesid");
            return (Criteria) this;
        }

        public Criteria andVaccinesidGreaterThanOrEqualTo(Long value) {
            addCriterion("vaccinesId >=", value, "vaccinesid");
            return (Criteria) this;
        }

        public Criteria andVaccinesidLessThan(Long value) {
            addCriterion("vaccinesId <", value, "vaccinesid");
            return (Criteria) this;
        }

        public Criteria andVaccinesidLessThanOrEqualTo(Long value) {
            addCriterion("vaccinesId <=", value, "vaccinesid");
            return (Criteria) this;
        }

        public Criteria andVaccinesidIn(List<Long> values) {
            addCriterion("vaccinesId in", values, "vaccinesid");
            return (Criteria) this;
        }

        public Criteria andVaccinesidNotIn(List<Long> values) {
            addCriterion("vaccinesId not in", values, "vaccinesid");
            return (Criteria) this;
        }

        public Criteria andVaccinesidBetween(Long value1, Long value2) {
            addCriterion("vaccinesId between", value1, value2, "vaccinesid");
            return (Criteria) this;
        }

        public Criteria andVaccinesidNotBetween(Long value1, Long value2) {
            addCriterion("vaccinesId not between", value1, value2, "vaccinesid");
            return (Criteria) this;
        }

        public Criteria andInoculationidIsNull() {
            addCriterion("InoculationId is null");
            return (Criteria) this;
        }

        public Criteria andInoculationidIsNotNull() {
            addCriterion("InoculationId is not null");
            return (Criteria) this;
        }

        public Criteria andInoculationidEqualTo(Long value) {
            addCriterion("InoculationId =", value, "inoculationid");
            return (Criteria) this;
        }

        public Criteria andInoculationidNotEqualTo(Long value) {
            addCriterion("InoculationId <>", value, "inoculationid");
            return (Criteria) this;
        }

        public Criteria andInoculationidGreaterThan(Long value) {
            addCriterion("InoculationId >", value, "inoculationid");
            return (Criteria) this;
        }

        public Criteria andInoculationidGreaterThanOrEqualTo(Long value) {
            addCriterion("InoculationId >=", value, "inoculationid");
            return (Criteria) this;
        }

        public Criteria andInoculationidLessThan(Long value) {
            addCriterion("InoculationId <", value, "inoculationid");
            return (Criteria) this;
        }

        public Criteria andInoculationidLessThanOrEqualTo(Long value) {
            addCriterion("InoculationId <=", value, "inoculationid");
            return (Criteria) this;
        }

        public Criteria andInoculationidIn(List<Long> values) {
            addCriterion("InoculationId in", values, "inoculationid");
            return (Criteria) this;
        }

        public Criteria andInoculationidNotIn(List<Long> values) {
            addCriterion("InoculationId not in", values, "inoculationid");
            return (Criteria) this;
        }

        public Criteria andInoculationidBetween(Long value1, Long value2) {
            addCriterion("InoculationId between", value1, value2, "inoculationid");
            return (Criteria) this;
        }

        public Criteria andInoculationidNotBetween(Long value1, Long value2) {
            addCriterion("InoculationId not between", value1, value2, "inoculationid");
            return (Criteria) this;
        }

        public Criteria andInoculationTimeIsNull() {
            addCriterion("Inoculation_time is null");
            return (Criteria) this;
        }

        public Criteria andInoculationTimeIsNotNull() {
            addCriterion("Inoculation_time is not null");
            return (Criteria) this;
        }

        public Criteria andInoculationTimeEqualTo(Date value) {
            addCriterion("Inoculation_time =", value, "inoculationTime");
            return (Criteria) this;
        }

        public Criteria andInoculationTimeNotEqualTo(Date value) {
            addCriterion("Inoculation_time <>", value, "inoculationTime");
            return (Criteria) this;
        }

        public Criteria andInoculationTimeGreaterThan(Date value) {
            addCriterion("Inoculation_time >", value, "inoculationTime");
            return (Criteria) this;
        }

        public Criteria andInoculationTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("Inoculation_time >=", value, "inoculationTime");
            return (Criteria) this;
        }

        public Criteria andInoculationTimeLessThan(Date value) {
            addCriterion("Inoculation_time <", value, "inoculationTime");
            return (Criteria) this;
        }

        public Criteria andInoculationTimeLessThanOrEqualTo(Date value) {
            addCriterion("Inoculation_time <=", value, "inoculationTime");
            return (Criteria) this;
        }

        public Criteria andInoculationTimeIn(List<Date> values) {
            addCriterion("Inoculation_time in", values, "inoculationTime");
            return (Criteria) this;
        }

        public Criteria andInoculationTimeNotIn(List<Date> values) {
            addCriterion("Inoculation_time not in", values, "inoculationTime");
            return (Criteria) this;
        }

        public Criteria andInoculationTimeBetween(Date value1, Date value2) {
            addCriterion("Inoculation_time between", value1, value2, "inoculationTime");
            return (Criteria) this;
        }

        public Criteria andInoculationTimeNotBetween(Date value1, Date value2) {
            addCriterion("Inoculation_time not between", value1, value2, "inoculationTime");
            return (Criteria) this;
        }

        public Criteria andUseridIsNull() {
            addCriterion("UserId is null");
            return (Criteria) this;
        }

        public Criteria andUseridIsNotNull() {
            addCriterion("UserId is not null");
            return (Criteria) this;
        }

        public Criteria andUseridEqualTo(Long value) {
            addCriterion("UserId =", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridNotEqualTo(Long value) {
            addCriterion("UserId <>", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridGreaterThan(Long value) {
            addCriterion("UserId >", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridGreaterThanOrEqualTo(Long value) {
            addCriterion("UserId >=", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridLessThan(Long value) {
            addCriterion("UserId <", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridLessThanOrEqualTo(Long value) {
            addCriterion("UserId <=", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridIn(List<Long> values) {
            addCriterion("UserId in", values, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridNotIn(List<Long> values) {
            addCriterion("UserId not in", values, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridBetween(Long value1, Long value2) {
            addCriterion("UserId between", value1, value2, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridNotBetween(Long value1, Long value2) {
            addCriterion("UserId not between", value1, value2, "userid");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}
package com.vacc.web.pojo;

public class InspectType {
    private Integer id;

    private String inspectType;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getInspectType() {
        return inspectType;
    }

    public void setInspectType(String inspectType) {
        this.inspectType = inspectType == null ? null : inspectType.trim();
    }
}
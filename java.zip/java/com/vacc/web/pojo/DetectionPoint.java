package com.vacc.web.pojo;

import java.util.Date;

public class DetectionPoint {
    private Integer detectionid;

    private Long areaid;

    private String detailedAddress;

    private String name;

    private Date starttime;

    private Date endtime;

    @Override
    public String toString() {
        return "DetectionPoint{" +
                "detectionid=" + detectionid +
                ", areaid=" + areaid +
                ", detailedAddress='" + detailedAddress + '\'' +
                ", name='" + name + '\'' +
                ", starttime=" + starttime +
                ", endtime=" + endtime +
                '}';
    }

    public Integer getDetectionid() {
        return detectionid;
    }

    public void setDetectionid(Integer detectionid) {
        this.detectionid = detectionid;
    }

    public Long getAreaid() {
        return areaid;
    }

    public void setAreaid(Long areaid) {
        this.areaid = areaid;
    }

    public String getDetailedAddress() {
        return detailedAddress;
    }

    public void setDetailedAddress(String detailedAddress) {
        this.detailedAddress = detailedAddress == null ? null : detailedAddress.trim();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public Date getStarttime() {
        return starttime;
    }

    public void setStarttime(Date starttime) {
        this.starttime = starttime;
    }

    public Date getEndtime() {
        return endtime;
    }

    public void setEndtime(Date endtime) {
        this.endtime = endtime;
    }
}
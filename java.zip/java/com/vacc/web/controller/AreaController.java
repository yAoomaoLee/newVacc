package com.vacc.web.controller;

import com.vacc.web.pojo.Area;
import com.vacc.web.pojo.City;
import com.vacc.web.pojo.Province;
import com.vacc.web.service.AreaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller //负责地区模块的controller
public class AreaController {
    @Autowired
    private AreaService areaService;

    //查询所有省份
    @RequestMapping("/findAllProvince")
    @ResponseBody
    public List<Province> findAllProvince(){
        System.out.println("查看所有省份++++++++++++++");
        List<Province> provinceList=areaService.findAllProvince();
        /*for (Province province:provinceList) {
            System.out.println(province);
        }*/
        return provinceList;
    }
    //根据省份查看所有城市
    @RequestMapping("/findCityByProvince")
    @ResponseBody
    public List<City> findCityByProvince(String provinceid){
        System.out.println("根据省份查看所有城市,省份编号:"+provinceid);
        List<City> cityList=areaService.findCityByProvince(provinceid);
        /*for (City city:cityList) {
            System.out.println(city);
        }*/
        return cityList;
    }

    //根据市查看所有县/区
    @RequestMapping("/findAreaByCity")
    @ResponseBody
    public List<Area> findAreaByCity(String cityid){
        System.out.println("根据市查看所有县/区,市编号:"+cityid);
        List<Area> areaList=areaService.findAreaByCity(cityid);
        /*for (Area area:areaList) {
            System.out.println(area);
        }*/
        return areaList;
    }
}

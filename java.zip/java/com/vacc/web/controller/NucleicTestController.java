package com.vacc.web.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.vacc.web.pojo.NucleicAndDection;
import com.vacc.web.pojo.NucleicTest;
import com.vacc.web.pojo.User;
import com.vacc.web.service.NucleicTestService;
import com.vacc.web.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpSession;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

//核酸检测结果
@Controller
public class NucleicTestController {

    @Autowired
    private NucleicTestService nucleicTestService;

    @Autowired
    private UserService userService;

    @RequestMapping("/nucleicTest")
    @ResponseBody
    public String nucleicTest(HttpSession session){
        User user= (User) session.getAttribute("user");
        NucleicTest nucleicTest=new NucleicTest();
        nucleicTest.setUserid(user.getId());
        nucleicTest.setTime(new Date());
        int i=nucleicTestService.nucleicTest(nucleicTest);
        if(i>0){
            return "SUCCESS";
        }
        return "FAIL";
    }
    @RequestMapping("/myNucleicResult")    //我的检测记录
    public ModelAndView myNucleicResult(HttpSession session){
        User user= (User) session.getAttribute("user");
        ModelAndView mv=new ModelAndView();
        List<NucleicAndDection> nucleicTestList=nucleicTestService.selectMyNucleicResult(user.getId());
        mv.addObject("nucleicTestList",nucleicTestList);
        mv.setViewName("mynucleicresult");
        return mv;
    }
    @RequestMapping("/allNucleicResult")   //查询全部核酸检测结果
    @ResponseBody
    public ModelAndView allNucleicResult(){
        ModelAndView mv=new ModelAndView();
        List<NucleicAndDection> nucleicAndDectionList=nucleicTestService.selectAllNucleicResult();
        mv.addObject("nucleicAndDectionList",nucleicAndDectionList);
        mv.setViewName("allnucleicresult");
        return mv;
    }
    @RequestMapping("/findAllNucleicTestResult")
    @ResponseBody
    //查询用户全部核酸结果
    public Map findAllNucleicTestResult(String name,Date time,Integer result,Integer detectionid,HttpSession session){
        Map map=new HashMap();
        List<NucleicTest> nucleicTestList=nucleicTestService.selectNucleicTestResult(name,time,result,detectionid);
        map.put("nucleicTestList",nucleicTestList);
        return map;
    }
    @RequestMapping("/entryResult")
    @ResponseBody
    public String entryResult(long resultId,long detectionid,byte result,Long userid){
        System.out.println("resultId:"+resultId+",detectionid:"+detectionid+",result:"+result+",userid:"+userid);
        if(result==1){
            userService.updateHealthStatusByUserId(userid);
        }
        else {
            userService.updateHealthStatusByUserId2(userid);
        }
        NucleicTest nucleicTest=new NucleicTest(resultId,new Date(),detectionid,result);
        int i=nucleicTestService.entryResult(nucleicTest);
        if(i>0){
            return "SUCCESS";
        }
        return "FAIL";
    }
}

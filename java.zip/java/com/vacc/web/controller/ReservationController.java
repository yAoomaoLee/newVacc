package com.vacc.web.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.vacc.web.pojo.*;
import com.vacc.web.service.ISiteAndVaccService;
import com.vacc.web.service.ReservationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpSession;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Controller  //预约记录
public class ReservationController {

    @Autowired
    private ReservationService reservationService;

    @Autowired
    private ISiteAndVaccService iSiteAndVaccService;

    @RequestMapping("/findAllReservationHist")
    public ModelAndView findAllReservationHist(HttpSession session, @RequestParam(name = "pageNo",required = false,defaultValue = "1") int pageNo,
                                               @RequestParam(name = "pageSize",required = false,defaultValue = "5") int pageSize){
        User user = (User) session.getAttribute("user");
        ModelAndView mv=new ModelAndView();
        PageHelper.startPage(pageNo,pageSize);   //开启分页
        List<Reservation> reservationList=reservationService.findAllReservationHist(user.getId());
        mv.addObject("reservationList",reservationList);
        PageInfo pageInfo=new PageInfo<>(reservationList);  //存储分页信息
        mv.addObject("pageInfo",pageInfo);
        mv.setViewName("reservationHistoty");
        return mv;
    }

    @RequestMapping("/addReservation")
    @ResponseBody    //添加预约信息
    public String addReservation(Reservation reservation,Long ivId){
        if(reservation==null){
            return "FAIL";
        }
        //判断如果预约的时间在接种结束时间之后
        if(new Date().compareTo(reservation.getEndtime())>0){
            return "FAIL";
        }
        reservation.setReservationtime(new Date());
        int i=reservationService.addReservation(reservation);
        if(i>0){
            int j=iSiteAndVaccService.deleteOne(ivId);
            return "SUCCESS";
        }
        return "FAIL";
    }
    @RequestMapping("/addInoculationHistory")
    @ResponseBody    //添加接种记录
    public String addInoculationHistory(InoculationHistory inoculationHistory,int id){
        inoculationHistory.setInoculationTime(new Date());
        inoculationHistory.setNum(1);
        System.out.println(inoculationHistory);
        SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        int i=reservationService.addInoculationHistory(inoculationHistory);
        if(i>0){
            reservationService.updateStuts(id);
            return "SUCCESS";
        }
        return "FAIL";
    }
    @RequestMapping("/cancelRese")
    @ResponseBody    //取消预约
    public String cancelRese(InoculationHistory inoculationHistory,int id){
        System.out.println(inoculationHistory);
        int i=reservationService.updateCancelStuts(id);
        List<IVaccines> iVaccinesList=iSiteAndVaccService.findAllIVacc();
        for (IVaccines iVaccines:iVaccinesList) {
            if(iVaccines.getVaccinesid()==inoculationHistory.getVaccinesid()&&
                    iVaccines.getInoculationid()==inoculationHistory.getInoculationid()){
                iSiteAndVaccService.addOne(iVaccines.getId());
            }
        }
        if(i>0){
            return "SUCCESS";
        }
        return "FAIL";
    }
}

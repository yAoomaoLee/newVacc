package com.vacc.web.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.vacc.web.pojo.ISiteAndVacc;
import com.vacc.web.pojo.Vaccines;
import com.vacc.web.service.ISiteAndVaccService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.util.Date;
import java.util.List;

@Controller
public class ISiteAndVaccController {

    @Autowired
    private ISiteAndVaccService siteAndVaccService;

    @RequestMapping("/findAllISiteAndVacc")
    public ModelAndView findAllISiteAndVacc(ISiteAndVacc iSiteAndVacc,
                                        @RequestParam(name = "pageNo",required = false,defaultValue = "1") int pageNo,
                                        @RequestParam(name = "pageSize",required = false,defaultValue = "5") int pageSize){
        System.out.println(iSiteAndVacc+"++++++++++");
        ModelAndView mv=new ModelAndView();
        PageHelper.startPage(pageNo,pageSize);   //开启分页
        List<ISiteAndVacc> iSiteAndVaccList=siteAndVaccService.findAllISiteAndVacc(iSiteAndVacc);
        mv.addObject("iSiteAndVaccList",iSiteAndVaccList);
        PageInfo pageInfo=new PageInfo<>(iSiteAndVaccList);  //存储分页信息
        mv.addObject("pageInfo",pageInfo);
        mv.setViewName("iSiteAndVacc");
        return mv;
    }

    @RequestMapping("/addiSiteAndVaccById")
    @ResponseBody
    public ISiteAndVacc addiSiteAndVaccById(Long id){
        System.out.println("要预约的id"+id);
        ISiteAndVacc iSiteAndVaccs = siteAndVaccService.addiSiteAndVaccById(id);
        System.out.println("要预约的");
        return iSiteAndVaccs;
    }
}

package com.vacc.web.controller;

import com.vacc.web.pojo.Province;
import com.vacc.web.pojo.User;
import com.vacc.web.service.AreaService;
import com.vacc.web.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.ClassUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpSession;
import java.io.File;
import java.io.IOException;
import java.util.List;

/*
* 用户控制器
* */
@Controller
public class UserController {

    @Autowired
    private UserService userService;

    @Autowired
    private AreaService areaService;
   

    @RequestMapping("/doLogin")
    public String doLogin(String name, String password, String inputCode, HttpSession session, Model model){
        if(inputCode==null){
            return "login";
        }
       /* if(!inputCode.equals(session.getAttribute("vrifyCode"))){
            model.addAttribute("errorMsg","验证码错误");
            return "login";
        }*/
        if(name==null||password==null){   //防止刷新直接访问doLogin
            return "redirect:/login.ftl";
        }
        User user=userService.doLogin(name,password);
        if(user!=null){
            session.setAttribute("user",user);
            model.addAttribute("user",user);
            session.setMaxInactiveInterval(-1);  //设置session不失效
            return "index";
        }else{
            model.addAttribute("errorMsg","用户名或密码错误");
            return "login";
        }
    }

    @RequestMapping("/loginOut")  //退出登录
    public String loginOut(HttpSession session){
        session.invalidate();   //清空session
        return "login";  //返回登录页面
    }

    //注册
    @RequestMapping("/doRegister")
    public String doRegister(User user,Model model){
        user.setHealthStatus(0);
        user.setPic("bg2.jpg");
        int i=userService.doRegiseter(user);
//        if(i>0){
//            model.addAttribute("errorMsg","注册成功");
//        }else{
//            model.addAttribute("errorMsg","用户已存在,注册失败");
//        }
//        return "login";
        if(i > 0){
            model.addAttribute("errorMsg", "注册成功");
            model.addAttribute("errorIcon", 1); // 1 represents icon for success
        } else {
            model.addAttribute("errorMsg", "用户已存在，注册失败");
            model.addAttribute("errorIcon", 2); // 2 represents icon for failure
        }

        return "login";
    }

    @RequestMapping("/recode.ftl")
    public String recode(HttpSession session,Model model){
        User user1 = (User)session.getAttribute("user");
        User user=userService.doLogin(user1.getName(),user1.getPassword());
        session.setAttribute("user",user);
        model.addAttribute("user",user);
        session.setMaxInactiveInterval(-1);  //设置session不失效

        return "recode";
    }

    //修改登录用户信息
    @PostMapping("/updateUserMassage")
    @ResponseBody
    public String updateUserMassage(User user, @PathVariable(value = "uploadpic",required = false) MultipartFile uploadpic, HttpSession session) throws IOException {
        if(uploadpic.getSize()>0){
            String path=session.getServletContext().getRealPath("images");
            System.out.println("修改图片路径:"+path);
            File odlPic=new File(path,user.getPic());
            if(odlPic.exists()){   //判断旧图片是否存在
                odlPic.delete();  //删除旧图片
            }
            //获取图片上传路径
            //String paths= ClassUtils.getDefaultClassLoader().getResource("").getPath()+"static/images/";
            String paths="F:\\Java706-820\\newVacc\\src\\main\\resources\\static\\images\\";
            File newPic=new File(paths,uploadpic.getOriginalFilename());
            uploadpic.transferTo(newPic);  //存储图片
        }
        user.setPic(uploadpic.getOriginalFilename());
        int i=userService.updateUserMassage(user);
        if(i>0){
            return "SUCCESS";
        }
        return "FAIL";
    }
}

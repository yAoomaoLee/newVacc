package com.vacc.web.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.vacc.web.pojo.InoculationHistory2;
import com.vacc.web.pojo.User;
import com.vacc.web.service.InoculationHistoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpSession;
import java.util.List;

@Controller  //接种记录表
public class InoculationHistoryController {

    @Autowired
    private InoculationHistoryService historyService;

    @RequestMapping("/findAllInoculationHistory")
    public ModelAndView findAllInoculationHistory(HttpSession session,
                                                  @RequestParam(name = "pageNo",required = false,defaultValue = "1") int pageNo,
                                                  @RequestParam(name = "pageSize",required = false,defaultValue = "5") int pageSize){
        User user = (User) session.getAttribute("user");
        ModelAndView mv=new ModelAndView();
        PageHelper.startPage(pageNo,pageSize);   //开启分页
        List<InoculationHistory2> inoculationHistorys=historyService.findAllInoculationHistory(user.getId());
        for (InoculationHistory2 i:inoculationHistorys) {
            System.out.println(i);
        }
        mv.addObject("inoculationHistorys",inoculationHistorys);
        PageInfo pageInfo=new PageInfo<>(inoculationHistorys);  //存储分页信息
        mv.addObject("pageInfo",pageInfo);
        mv.setViewName("inoculationHistory");
        return mv;
    }
}

package com.vacc.web.controller;

import com.vacc.web.QRcode.QRCodeService;
import com.vacc.web.pojo.User;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@RestController
@Slf4j
public class QRCodeController {
    @Autowired
    private QRCodeService qrCodeService;

    @GetMapping("qrCode")
    public void getQRCode(Integer healthStatus, HttpServletResponse response, HttpSession session) {
        User user= (User) session.getAttribute("user");
        String codeContent="姓名:"+user.getName()+",身份证:"+user.getIdcard();
        try {
            qrCodeService.createQRCode2Stream(healthStatus,codeContent, response,user.getPic());
            log.info("成功生成二维码！");
        } catch (Exception e) {
            log.error("发生错误， 错误信息是：{}！", e.getMessage());
        }
    }

}

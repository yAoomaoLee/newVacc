package com.vacc.web.controller;

import com.vacc.web.pojo.*;
import com.vacc.web.service.AreaService;
import com.vacc.web.service.HealthreportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.util.Date;
import java.util.List;

@Controller
public class HealthreportController {

    @Autowired
    private AreaService areaService;

    @Autowired
    private HealthreportService healthreportService;

    @RequestMapping("/findReportProvince")
    public ModelAndView findReportProvince(){
        ModelAndView mv=new ModelAndView();

        List<Province> provinceList=areaService.findAllProvince();
        mv.addObject("provinceList",provinceList);

        List<City> cityList=areaService.findAllCity();
        mv.addObject("cityList",cityList);

        List<Area> areaList=areaService.findAllArea();
        mv.addObject("areaList",areaList);

        mv.setViewName("healthreport");
        return mv;
    }
    @RequestMapping("/addHealthreport")
    @ResponseBody
    public String addHealthreport(Healthreport healthreport){
        System.out.println("++++++++++++++"+healthreport);
        healthreport.setReportingtime(new Date());
        int i=healthreportService.addHealthreport(healthreport);
        if(i>0){
            return "SUCCESS";
        }
        return "FAIL";
    }
}

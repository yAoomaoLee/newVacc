package com.vacc.web.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.vacc.web.pojo.Vaccines;
import com.vacc.web.service.VaccineService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;
//疫苗管理-疫苗录入
@Controller
public class VaccinesController {

    @Autowired
    private VaccineService vaccineService;

    @RequestMapping("/findAllVaccines")
    public ModelAndView findAllVaccines(@RequestParam(name = "pageNo",required = false,defaultValue = "1") int pageNo,
                                        @RequestParam(name = "pageSize",required = false,defaultValue = "5") int pageSize){
        ModelAndView mv=new ModelAndView();
        PageHelper.startPage(pageNo,pageSize);   //开启分页
        List<Vaccines> vaccinesList=vaccineService.findAllVaccines();
        mv.addObject("vaccinesList",vaccinesList);
        PageInfo pageInfo=new PageInfo<>(vaccinesList);  //存储分页信息
        mv.addObject("pageInfo",pageInfo);
        mv.setViewName("vaccinesInfo");
        return mv;
    }
    @GetMapping("/findAllVacc")
    @ResponseBody
    public List<Vaccines> findAllVacc(){
        return vaccineService.findAllVaccines();
    }
    @RequestMapping("/addVacc")
    @ResponseBody
    public String addVacc(Vaccines vaccines){
        System.out.println("++++++++++++++"+vaccines);
        int i=vaccineService.addVacc(vaccines);
        if(i>0){
            return "SUCCESS";
        }
        return "FAIL";
    }
    @RequestMapping("/updateVaccById")
    @ResponseBody
    public Vaccines updateVaccById(Long vaccinesid){
        System.out.println("要修改的id"+vaccinesid);
        Vaccines vaccines=vaccineService.findVaccById(vaccinesid);
        System.out.println("要修改的"+vaccines);
        return vaccines;
    }  //updateVacc
    @RequestMapping("/updateVacc")
    @ResponseBody
    public int updateVacc(Vaccines vaccines){
        System.out.println("++++++++++++++"+vaccines);
        int i=vaccineService.updateVacc(vaccines);
        return i;
    }  //deleteVaccById
    @RequestMapping("/deleteVaccById")
    @ResponseBody
    public String deleteVaccById(Long vaccinesid){
        System.out.println("要删除的id"+vaccinesid);
        int i=vaccineService.deleteVaccById(vaccinesid);
        if(i>0){
            return "SUSSES";
        }
        return "FAIL";
    }
}

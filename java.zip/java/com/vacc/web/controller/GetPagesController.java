package com.vacc.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import javax.servlet.http.HttpSession;

@Controller
public class GetPagesController {

    @GetMapping("{url}.ftl")  //访问页面跳转到指定页面
    public String getPage(@PathVariable("url") String url, HttpSession session){
        System.out.println();
            return url;


    }

}

package com.vacc.web.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.vacc.web.pojo.*;
import com.vacc.web.service.AreaService;
import com.vacc.web.service.InoculationSiteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

//接种点管理
@Controller
public class InoculationSiteController {

    @Autowired
    private InoculationSiteService iSiteService;

    @Autowired
    private AreaService areaService;

    @RequestMapping("/findAllISite")   //查找所有接种点
    public ModelAndView findAllISite(@RequestParam(name = "pageNo",required = false,defaultValue = "1") int pageNo,
                                              @RequestParam(name = "pageSize",required = false,defaultValue = "5") int pageSize){
        ModelAndView mv=new ModelAndView();
        PageHelper.startPage(pageNo,pageSize);   //开启分页
        List<I_SiteAndArea> siteList=iSiteService.findAllISite();
        for (InoculationSite site:siteList) {
            System.out.println(site);
        }
        mv.addObject("siteList",siteList);
        PageInfo pageInfo=new PageInfo<>(siteList);  //存储分页信息
        mv.addObject("pageInfo",pageInfo);
        List<Province> provinceList=areaService.findAllProvince();
        mv.addObject("provinceList",provinceList);
        List<City> cityList=areaService.findAllCity();
        mv.addObject("cityList",cityList);
        List<Area> areaList=areaService.findAllArea();
        mv.addObject("areaList",areaList);
        mv.setViewName("inoculationSite");
        return mv;
    }

    @RequestMapping("/addInoculationSite")
    @ResponseBody    //添加接种点
    public String addInoculationSite(InoculationSite inoculationSite){
        System.out.println("++++++++++++++"+inoculationSite);
        int i=iSiteService.addInoculationSite(inoculationSite);
        if(i>0){
            return "SUCCESS";
        }
        return "FAIL";
    }
    @RequestMapping("/updateInoculationSite")
    @ResponseBody    //修改核酸检测点
    public String updateInoculationSite(InoculationSite inoculationSite){
        System.out.println("++++++++++++++"+inoculationSite);
        int i=iSiteService.updateInoculationSite(inoculationSite);
        if(i>0){
            return "SUCCESS";
        }
        return "FAIL";
    }

    @RequestMapping("/updateInoculationSiteById")
    @ResponseBody
    public InoculationSite updateInoculationSiteById(Long inoculationid){
        System.out.println("要修改的id"+inoculationid);
        InoculationSite inoculationSite = iSiteService.findinoculationById(inoculationid);
        System.out.println("要修改的"+inoculationSite);
        return inoculationSite;
    }



    @RequestMapping("/deleteByInoculationid")
    @ResponseBody   //删除核酸检测点
    public String deleteByInoculationid(Long inoculationid){
        System.out.println("要删除的id"+inoculationid);
        int i=iSiteService.deleteByInoculationid(inoculationid);
        if(i>0){
            return "SUCCESS";
        }
        return "FAIL";
    }
    @RequestMapping("/addIvaccine")
    @ResponseBody    //添加接种点
    public String addIvaccine(IVaccines iVaccines){
        System.out.println("++++++++++++++"+iVaccines);
        int i=iSiteService.addIvaccine(iVaccines);
        if(i>0){
            return "SUCCESS";
        }
        return "FAIL";
    }
}

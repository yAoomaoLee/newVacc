package com.vacc.web.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.vacc.web.pojo.Area;
import com.vacc.web.pojo.City;
import com.vacc.web.pojo.DetectionPoint;
import com.vacc.web.pojo.Province;
import com.vacc.web.service.AreaService;
import com.vacc.web.service.DetectionPointService;
import com.vacc.web.utils.AreaUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller  //核酸监测点控制器
public class DetectionPointController {

    @Autowired
    private DetectionPointService detectionPointService;

    @Autowired
    private AreaService areaService;

    @RequestMapping("/findAlldetectionPointajax")   //查找核酸检测点
    @ResponseBody
    public List<DetectionPoint> findAlldetectionPoint(){
        List<DetectionPoint> detectionPointList=detectionPointService.findAllDetectionPoint();
        return detectionPointList;
    }

    @RequestMapping("/findAlldetectionPoint")   //查找核酸检测点
    public ModelAndView findAlldetectionPoint(@RequestParam(name = "pageNo",required = false,defaultValue = "1") int pageNo,
                                              @RequestParam(name = "pageSize",required = false,defaultValue = "5") int pageSize){
        ModelAndView mv=new ModelAndView();
        PageHelper.startPage(pageNo,pageSize);   //开启分页
        List<DetectionPoint> detectionPointList=detectionPointService.findAllDetectionPoint();
        mv.addObject("detectionPointList",detectionPointList);
        PageInfo pageInfo=new PageInfo<>(detectionPointList);  //存储分页信息
        mv.addObject("pageInfo",pageInfo);
        List<Province> provinceList=areaService.findAllProvince();
        mv.addObject("provinceList",provinceList);
        List<City> cityList=areaService.findAllCity();
        mv.addObject("cityList",cityList);
        List<Area> areaList=areaService.findAllArea();
        mv.addObject("areaList",areaList);
        mv.setViewName("detecionpoint");
        return mv;
    }
    @RequestMapping("/addDetectionPoint")
    @ResponseBody    //添加核酸检测点
    public String addDetectionPoint(DetectionPoint detectionPoint){
        System.out.println("++++++++++++++"+detectionPoint);
        int i=detectionPointService.addDetectionPoint(detectionPoint);
        if(i>0){
            return "SUCCESS";
        }
        return "FAIL";
    }

    @RequestMapping("/updateDPointById")
    @ResponseBody
    public DetectionPoint updateDPointById(Integer detectionid){
        System.out.println("要修改的id"+detectionid);
        DetectionPoint detectionPoint = detectionPointService.updateDPointById(detectionid);
        System.out.println("要修改的"+detectionPoint);
        return detectionPoint;
    }

    @RequestMapping("/updateDPoint")
    @ResponseBody    //修改核酸检测点
    public String updateDPoint(DetectionPoint detectionPoint){
        System.out.println("++++++++++++++"+detectionPoint);
        int i=detectionPointService.updateDPoint(detectionPoint);
        if(i>0){
            return "SUCCESS";
        }
        return "FAIL";
    }  //deleteVaccById
    @RequestMapping("/deleteDPointById")
    @ResponseBody   //删除核酸检测点
    public String deleteDPointById(Integer detectionid){
        System.out.println("要删除的id"+detectionid);
        int i=detectionPointService.deleteDPointById(detectionid);
        if(i>0){
            return "SUSSES";
        }
        return "FAIL";
    }
}

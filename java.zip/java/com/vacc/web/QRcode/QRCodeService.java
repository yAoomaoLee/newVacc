package com.vacc.web.QRcode;

import cn.hutool.core.io.FileUtil;
import cn.hutool.extra.qrcode.QrCodeException;
import cn.hutool.extra.qrcode.QrCodeUtil;
import cn.hutool.extra.qrcode.QrConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.ClassUtils;

import javax.servlet.http.HttpServletResponse;
import java.awt.*;
import java.io.File;
import java.io.IOException;

@Service
@Slf4j
public class QRCodeService {
    // 自定义参数，这部分是Hutool工具封装的
    private static QrConfig initQrConfig(Integer healthStatus,String picName) {
        QrConfig config = new QrConfig(400, 400);
        // 设置边距，既二维码和背景之间的边距
        config.setMargin(2);
        // 设置前景色，既二维码颜色（青色）

        int [] recodeColor={Color.green.getRGB(),Color.yellow.getRGB(),Color.red.getRGB()};
         config.setForeColor(recodeColor[healthStatus]);
        // 设置背景色（灰色）
        config.setBackColor(Color.white.getRGB());
        //获取图片的绝对路径
//        String basePath=ClassUtils.getDefaultClassLoader().getResource("").getPath()+"static/images/";
        String basePath="F:\\Java706-820\\newVacc\\src\\main\\resources\\static\\images\\";
        System.out.println("图片路径:"+basePath+picName);
        config.setImg(new File(basePath+picName));
        return config;
    }

    /**
     * 生成到文件
     *
     * @param content
     * @param filepath
     */
    public void createQRCode2File(Integer healthStatus,String content, String filepath, String picName) {
        try {
            QrCodeUtil.generate(content, initQrConfig(healthStatus,picName), FileUtil.file(filepath));
            log.info("生成二维码成功, 位置在：{}！", filepath);
        } catch (QrCodeException e) {
            log.error("发生错误！{}！", e.getMessage());
        }
    }

    /**
     * 生成到流
     *
     * @param healthStatus
     * @param content
     * @param response
     */
    public void createQRCode2Stream(Integer healthStatus, String content, HttpServletResponse response, String picName) {
        try {
            QrCodeUtil.generate(content, initQrConfig(healthStatus,picName), "png", response.getOutputStream());
            log.info("生成二维码成功!");
        } catch (QrCodeException | IOException e) {
            log.error("发生错误！{}！", e.getMessage());
        }
    }
}

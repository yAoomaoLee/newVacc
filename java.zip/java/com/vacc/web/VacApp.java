package com.vacc.web;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan("com.vacc.web.mapper")
public class VacApp {
    public static void main(String[] args) {
        SpringApplication.run(VacApp.class,args);
    }
}

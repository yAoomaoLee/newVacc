package com.vacc.web.service;

import com.vacc.web.pojo.InoculationHistory2;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface InoculationHistoryService {

    List<InoculationHistory2> findAllInoculationHistory(long userid);
}

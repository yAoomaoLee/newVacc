package com.vacc.web.service;

public interface InoculationHistory {


}

package com.vacc.web.service;

import com.vacc.web.pojo.IVaccines;
import com.vacc.web.pojo.I_SiteAndArea;
import com.vacc.web.pojo.InoculationSite;

import java.util.List;

public interface InoculationSiteService {

    //查找所有接种点
    List<I_SiteAndArea> findAllISite();

    //添加接种点
    int addInoculationSite(InoculationSite inoculationSite);

    //修改接种点
    int updateInoculationSite(InoculationSite inoculationSite);

    int updateInoculationSiteById(InoculationSite inoculationSite);

    //根据id删除接种点
    int deleteByInoculationid(Long inoculationid);

    //录入疫苗
    int addIvaccine(IVaccines iVaccines);

    InoculationSite findinoculationById(Long inoculationid);
}

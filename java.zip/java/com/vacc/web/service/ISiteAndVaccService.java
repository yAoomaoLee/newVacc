package com.vacc.web.service;

import com.vacc.web.pojo.ISiteAndVacc;
import com.vacc.web.pojo.IVaccines;

import java.util.List;

public interface ISiteAndVaccService {

    //查找所有接种疫苗
    List<ISiteAndVacc> findAllISiteAndVacc(ISiteAndVacc iSiteAndVacc);

    List<IVaccines> findAllIVacc();

    int deleteOne(Long ivId);

    int addOne(int id);

    ISiteAndVacc addiSiteAndVaccById(Long id);
}

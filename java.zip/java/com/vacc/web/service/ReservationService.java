package com.vacc.web.service;

import com.vacc.web.pojo.InoculationHistory;
import com.vacc.web.pojo.Reservation;

import java.util.List;

public interface ReservationService {


    int addReservation(Reservation reservation);

    //查找所有预约记录
    List<Reservation> findAllReservationHist(long id);

    int addInoculationHistory(InoculationHistory inoculationHistory);

    void updateStuts(int id);

    int updateCancelStuts(int id);
}

package com.vacc.web.service;

import com.vacc.web.pojo.User;

public interface UserService {

    //登录方法
    User doLogin(String name, String password);

    //根据用户id查找用户
    User findUserById(long id);

    int updateUserMassage(User user);

    int doRegiseter(User user);

    //根据用户id修改用户健康信息
    int updateHealthStatusByUserId(long userId);

    int updateHealthStatusByUserId2(long userId);
}

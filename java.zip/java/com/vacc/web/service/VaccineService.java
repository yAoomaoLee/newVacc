package com.vacc.web.service;

import com.vacc.web.pojo.Vaccines;

import java.util.List;

public interface VaccineService {

    //查看全部疫苗
    List<Vaccines> findAllVaccines();

    //添加疫苗
    int addVacc(Vaccines vaccines);

    //查看疫苗详细信息
    Vaccines findVaccById(Long vaccinesid);

    //修改疫苗信息
    int updateVacc(Vaccines vaccines);

    //删除疫苗信息
    int deleteVaccById(Long vaccinesid);
}

package com.vacc.web.service;

import com.vacc.web.pojo.Area;
import com.vacc.web.pojo.City;
import com.vacc.web.pojo.Province;

import java.util.List;

public interface AreaService {

    //查询所有省份
    List<Province> findAllProvince();

    //根据省份查询城市
    List<City> findCityByProvince(String provinceid);

    //根据市查看所有县/区
    List<Area> findAreaByCity(String cityid);

    //查找所有城市
    List<City> findAllCity();

    //查找所有地区
    List<Area> findAllArea();
}

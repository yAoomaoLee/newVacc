package com.vacc.web.service;

import com.vacc.web.pojo.NucleicAndDection;
import com.vacc.web.pojo.NucleicTest;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;

public interface NucleicTestService {

    //核酸检测
    int nucleicTest(NucleicTest nucleicTest);

    List<NucleicAndDection> selectMyNucleicResult(@Param("userid") Long userid);

    List<NucleicAndDection> selectAllNucleicResult();

    //查询全部用户核酸结果
    List<NucleicTest> selectNucleicTestResult(String name,Date time,Integer result,Integer detectionid);

    int entryResult(NucleicTest nucleicTest);
}

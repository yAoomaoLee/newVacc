package com.vacc.web.service;

import com.vacc.web.pojo.DetectionPoint;

import java.util.List;

public interface DetectionPointService {

    //查询所有检测点
    List<DetectionPoint> findAllDetectionPoint();

    //添加检测点
    int addDetectionPoint(DetectionPoint detectionPoint);

    //修改检测点
    int updateDPoint(DetectionPoint detectionPoint);

    //根据id修改检测点
    DetectionPoint updateDPointById(Integer detectionid);

    //删除检测点
    int deleteDPointById(Integer detectionid);

}

package com.vacc.web.service;

import com.vacc.web.pojo.Healthreport;

public interface HealthreportService {

    int addHealthreport(Healthreport healthreport);
}

package com.vacc.web.service.impl;

import com.vacc.web.mapper.IVaccinesMapper;
import com.vacc.web.mapper.I_SiteAndAreaMapper;
import com.vacc.web.mapper.InoculationSiteMapper;
import com.vacc.web.pojo.IVaccines;
import com.vacc.web.pojo.I_SiteAndArea;
import com.vacc.web.pojo.InoculationSite;
import com.vacc.web.service.InoculationSiteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service   //接种点service的实现层
public class InoculationSiteServiceImpl implements InoculationSiteService {

    @Autowired
    private InoculationSiteMapper siteMapper;

    @Autowired
    private I_SiteAndAreaMapper i_SiteAndAreaMapper;

    @Autowired
    private IVaccinesMapper iVaccinesMapper;

    @Override   //查找所有接种点
    public List<I_SiteAndArea> findAllISite() {
        return i_SiteAndAreaMapper.findAllIsByAreaId();
    }

    @Override
    public int addInoculationSite(InoculationSite inoculationSite) {
        return siteMapper.insert(inoculationSite);
    }

    @Override
    public int updateInoculationSite(InoculationSite inoculationSite) {
        return siteMapper.updateByPrimaryKey(inoculationSite);
    }

    @Override
    public int updateInoculationSiteById(InoculationSite inoculationSite) {
        return siteMapper.updateByPrimaryKey(inoculationSite);
    }

    @Override
    public int deleteByInoculationid(Long inoculationid) {
        return siteMapper.deleteByPrimaryKey(inoculationid);
    }

    @Override
    public int addIvaccine(IVaccines iVaccines) {
        return iVaccinesMapper.insert(iVaccines);
    }

    @Override
    public InoculationSite findinoculationById(Long inoculationid) {

        return siteMapper.selectByPrimaryKey(inoculationid);
    }
}

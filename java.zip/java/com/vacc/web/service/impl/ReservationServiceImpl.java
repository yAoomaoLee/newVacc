package com.vacc.web.service.impl;

import com.vacc.web.mapper.InoculationHistoryMapper;
import com.vacc.web.mapper.ReservationMapper;
import com.vacc.web.pojo.InoculationHistory;
import com.vacc.web.pojo.Reservation;
import com.vacc.web.pojo.ReservationExample;
import com.vacc.web.service.ReservationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReservationServiceImpl implements ReservationService {

    @Autowired
    private ReservationMapper reservationMapper;

    @Autowired
    private InoculationHistoryMapper historyMapper;

    @Override
    public int addReservation(Reservation reservation) {
        return reservationMapper.insert(reservation);
    }

    @Override
    public List<Reservation> findAllReservationHist(long id) {
        ReservationExample example=new ReservationExample();
        ReservationExample.Criteria criteria=example.createCriteria();
        int id2=(int)id;
        criteria.andUseridEqualTo(id2);
        return reservationMapper.selectByExample(example);
    }

    @Override
    public int addInoculationHistory(InoculationHistory inoculationHistory) {
        return historyMapper.insert(inoculationHistory);
    }

    @Override
    public void updateStuts(int id) {
        reservationMapper.updateStuts(id);
    }

    @Override
    public int updateCancelStuts(int id) {
        return reservationMapper.updateCancelStuts(id);
    }
}

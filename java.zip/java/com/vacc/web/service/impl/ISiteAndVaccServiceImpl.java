package com.vacc.web.service.impl;

import com.vacc.web.mapper.ISiteAndVaccMapper;
import com.vacc.web.mapper.IVaccinesMapper;
import com.vacc.web.pojo.ISiteAndVacc;
import com.vacc.web.pojo.IVaccines;
import com.vacc.web.service.ISiteAndVaccService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ISiteAndVaccServiceImpl implements ISiteAndVaccService {

    @Autowired
    private ISiteAndVaccMapper iSiteAndVaccMapper;

    @Autowired
    private IVaccinesMapper iVaccinesMapper;
    @Override
    public List<ISiteAndVacc> findAllISiteAndVacc(ISiteAndVacc iSiteAndVacc) {  //查看所有疫苗
        return iSiteAndVaccMapper.findAllISiteAndVacc(iSiteAndVacc.getVaccinesname(),iSiteAndVacc.getManufactor(),iSiteAndVacc.getInoculationname(),iSiteAndVacc.getStarttime());
    }

    @Override
    public List<IVaccines> findAllIVacc() {
        return iVaccinesMapper.selectByExample(null);
    }

    @Override
    public int deleteOne(Long ivId) {
        return iVaccinesMapper.deleteOne(ivId);
    }

    @Override
    public int addOne(int id) {
        return iVaccinesMapper.addOne(id);
    }

    @Override
    public ISiteAndVacc addiSiteAndVaccById(Long id) {
        return iSiteAndVaccMapper.addiSiteAndVaccById(id);
    }
}

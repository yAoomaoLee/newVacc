package com.vacc.web.service.impl;

import com.vacc.web.mapper.InoculationHistoryMapper;
import com.vacc.web.mapper.InoculationHistoryMapper2;
import com.vacc.web.pojo.InoculationHistory2;
import com.vacc.web.service.InoculationHistoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class InoculationHistoryServiceImpl implements InoculationHistoryService {

    @Autowired
    private InoculationHistoryMapper2 historyMapper2;

    @Override
    public List<InoculationHistory2> findAllInoculationHistory(long userid) {
        return historyMapper2.findAllInoculationHistory(userid);
    }
}

package com.vacc.web.service.impl;

import com.vacc.web.mapper.UserMapper;
import com.vacc.web.pojo.User;
import com.vacc.web.pojo.UserExample;
import com.vacc.web.service.UserService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    @Resource
    private UserMapper userMapper;
    @Override
    public User doLogin(String name, String password) {
        UserExample userExample=new UserExample();
        UserExample.Criteria criteria=userExample.createCriteria();
        criteria.andNameEqualTo(name);
        criteria.andPasswordEqualTo(password);
        List<User> userList=userMapper.selectByExample(userExample);
        if (userList!=null&&userList.size()>0){
            return userList.get(0);
        }
        return null;
    }
    @Override
    public User findUserById(long id) {
        return userMapper.selectByPrimaryKey(id);
    }

    @Override
    public int updateUserMassage(User user) {
        System.out.println(user);
        return userMapper.updateByPrimaryKey(user);
    }

    @Override
    public int doRegiseter(User user) {
        return userMapper.insertSelective(user);
    }

    @Override
    public int updateHealthStatusByUserId(long userId) {
        return userMapper.updateHealthStatusByUserId(userId);
    }

    @Override
    public int updateHealthStatusByUserId2(long userId) {
        return userMapper.updateHealthStatusByUserId2(userId);
    }



}

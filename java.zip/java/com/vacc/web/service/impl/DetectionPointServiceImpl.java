package com.vacc.web.service.impl;

import com.vacc.web.mapper.DetectionPointMapper;
import com.vacc.web.pojo.DetectionPoint;
import com.vacc.web.service.DetectionPointService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DetectionPointServiceImpl implements DetectionPointService {


    @Autowired
    private DetectionPointMapper detectionPointMapper;

    @Override
    public List<DetectionPoint> findAllDetectionPoint() {
        return detectionPointMapper.selectByExample(null);
    }

    @Override
    public int addDetectionPoint(DetectionPoint detectionPoint) {
        return detectionPointMapper.insert(detectionPoint);
    }

    @Override
    public int updateDPoint(DetectionPoint detectionPoint) {
        return detectionPointMapper.updateByPrimaryKey(detectionPoint);
    }

    @Override
    public DetectionPoint updateDPointById(Integer detectionid) {
        return detectionPointMapper.selectByPrimaryKey(detectionid);
    }

    @Override
    public int deleteDPointById(Integer detectionid) {
        return detectionPointMapper.deleteByPrimaryKey(detectionid);
    }

    /*@Override
    public List<NucleicTest> selectResultIsNull() {
        NucleicTestExample nucleicTestExample=new NucleicTestExample();
        NucleicTestExample.Criteria criteria=nucleicTestExample.createCriteria();
        criteria.andResultIsNull();
        return nucleicTestMapper.selectByExample(nucleicTestExample);
    }*/
}

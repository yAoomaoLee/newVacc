package com.vacc.web.service.impl;

import com.vacc.web.mapper.AreaMapper;
import com.vacc.web.mapper.CityMapper;
import com.vacc.web.mapper.ProvinceMapper;
import com.vacc.web.pojo.*;
import com.vacc.web.service.AreaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AreaServiceImpl implements AreaService {

    @Autowired
    private ProvinceMapper provinceMapper;

    @Autowired
    private CityMapper cityMapper;

    @Autowired
    private AreaMapper areaMapper;

    @Override
    public List<Province> findAllProvince() {
        return provinceMapper.selectByExample(null);
    }

    @Override
    public List<City> findCityByProvince(String provinceid) {
        CityExample example=new CityExample();
        CityExample.Criteria criteria=example.createCriteria();
        criteria.andFatherEqualTo(provinceid);
        return cityMapper.selectByExample(example);
    }

    @Override
    public List<Area> findAreaByCity(String cityid) {
        AreaExample example=new AreaExample();
        AreaExample.Criteria criteria=example.createCriteria();
        criteria.andFatherEqualTo(cityid);
        return areaMapper.selectByExample(example);
    }

    @Override
    public List<City> findAllCity() {
        return cityMapper.selectByExample(null);
    }

    @Override
    public List<Area> findAllArea() {
        return areaMapper.selectByExample(null);
    }

}

package com.vacc.web.service.impl;

import com.vacc.web.mapper.HealthreportMapper;
import com.vacc.web.pojo.Healthreport;
import com.vacc.web.service.HealthreportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class HealthreportServiceImpl implements HealthreportService {

    @Autowired
    private HealthreportMapper healthreportMapper;
    @Override
    public int addHealthreport(Healthreport healthreport) {
        return healthreportMapper.insert(healthreport);
    }
}

package com.vacc.web.service.impl;

import com.vacc.web.mapper.VaccinesMapper;
import com.vacc.web.pojo.Vaccines;
import com.vacc.web.service.VaccineService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VaccineServiceImpl implements VaccineService {

    @Autowired
    private VaccinesMapper vaccinesMapper;
    @Override
    public List<Vaccines> findAllVaccines() {
        return vaccinesMapper.selectByExample(null);
    }

    @Override
    public int addVacc(Vaccines vaccines) {
        return vaccinesMapper.insert(vaccines);
    }

    @Override
    public Vaccines findVaccById(Long vaccinesid) {
        return vaccinesMapper.selectByPrimaryKey(vaccinesid);
    }

    @Override
    public int updateVacc(Vaccines vaccines) {
        return vaccinesMapper.updateByPrimaryKey(vaccines);
    }

    @Override
    public int deleteVaccById(Long vaccinesid) {
        return vaccinesMapper.deleteByPrimaryKey(vaccinesid);
    }
}

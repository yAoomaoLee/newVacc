package com.vacc.web.service.impl;

import com.vacc.web.mapper.NucleicAndDectionMapper;
import com.vacc.web.mapper.NucleicTestMapper;
import com.vacc.web.pojo.NucleicAndDection;
import com.vacc.web.pojo.NucleicTest;
import com.vacc.web.service.NucleicTestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class NucleicTestServiceImpl implements NucleicTestService {

    @Autowired
    private NucleicTestMapper nucleicTestMapper;
    @Autowired
    private NucleicAndDectionMapper nucleicAndDectionMapper;

    @Override
    public int nucleicTest(NucleicTest nucleicTest) {
        return nucleicTestMapper.insert(nucleicTest);
    }

    @Override
    public List<NucleicAndDection> selectMyNucleicResult(Long id) {
        return nucleicAndDectionMapper.selectMyNucleicResult(id);
    }

    //查询全部核酸结果
    @Override
    public List<NucleicAndDection> selectAllNucleicResult() {
        return nucleicAndDectionMapper.selectAllNucleicResult();
    }

    @Override
    public List<NucleicTest> selectNucleicTestResult(String name,Date time,Integer result,Integer detectionid) {
        return nucleicTestMapper.selectNucleicTestResult(name,time,result,detectionid);
    }

    @Override
    public int entryResult(NucleicTest nucleicTest) {
        return  nucleicTestMapper.updateByPrimaryKeySelective(nucleicTest);
    }

}
